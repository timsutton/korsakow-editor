package test;

import org.dsrg.soenea.domain.DomainObject;


public class Person extends DomainObject<Long> implements IPerson {

	private IPerson buddy;
	private int age;
	private String name;
	
	public Person(IPerson buddy, int age, String name) {
		this(0, buddy, age, name);
	}
	
	public Person(long id, IPerson buddy, int age, String name) {
		this(id, 0, buddy, age, name);
	}
	
	public Person(long id, long version, IPerson buddy, int age, String name) {
		super(id, version);
		this.buddy = buddy;
		this.age = age;
		this.name = name;
	}
	
	/* (non-Javadoc)
	 * @see IPerson#getBuddy()
	 */
	public IPerson getBuddy() {
		return buddy;
	}
	/* (non-Javadoc)
	 * @see IPerson#setBuddy(IPerson)
	 */
	public void setBuddy(IPerson buddy) {
		this.buddy = buddy;
	}
	/* (non-Javadoc)
	 * @see IPerson#getAge()
	 */
	public int getAge() {
		return age;
	}
	/* (non-Javadoc)
	 * @see IPerson#setAge(int)
	 */
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getCombinedAge() {
		return getAge()+buddy.getAge();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
