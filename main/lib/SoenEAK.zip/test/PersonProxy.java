package test;

import java.sql.SQLException;

import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.proxy.DomainObjectProxy;


public class PersonProxy extends DomainObjectProxy<Long, Person> implements IPerson {

	public PersonProxy(Long id) {
		super(id);
	}

	@Override
	protected Person getFromMapper(Long id) throws SQLException, DomainObjectCreationException {
		return PersonMapper.find(id);
	}
	
	public int getAge() {
		return getInnerObject().getAge();
	}

	public IPerson getBuddy() {
		return getInnerObject().getBuddy();
	}

	public void setAge(int age) {
		getInnerObject().setAge(age);
	}

	public void setBuddy(IPerson buddy) {
		getInnerObject().setBuddy(buddy);
	}

	public int getCombinedAge() {
		return getInnerObject().getCombinedAge();
	}

	public String getName() {
		return getInnerObject().getName();
	}

	public void setName(String name) {
		getInnerObject().setName(name);
	}

}
