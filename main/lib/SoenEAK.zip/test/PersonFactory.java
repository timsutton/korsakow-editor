package test;

import java.sql.SQLException;

import org.dsrg.soenea.uow.UoW;

public class PersonFactory {

	
	public static Person createNew(IPerson buddy, int age, String name) throws SQLException {
		return createNew(PersonTDG.getMaxId(), 1, buddy, age, name);
	}
	
	public static Person createNew(long id, long version, IPerson buddy, int age, String name) throws SQLException {
		Person p = new Person(id, version, buddy, age, name);
		UoW.getCurrent().registerNew(p);
		return p;
	}
	
	public static Person createClean(long id, long version, IPerson buddy, int age, String name) {
		Person p = new Person(id, version, buddy, age, name);
		UoW.getCurrent().registerClean(p);
		return p;		
	}
}
