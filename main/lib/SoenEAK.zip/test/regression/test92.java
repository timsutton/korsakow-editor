package test.regression;

import java.util.Arrays;

import junit.framework.Assert;

import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.role.impl.GuestRole;
import org.dsrg.soenea.domain.role.mapper.RoleOutputMapper;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.UserFactory;
import org.dsrg.soenea.domain.user.mapper.UserInputMapper;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.SingleAppUniqueIdFactory;
import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.tdg.UserTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class test92 {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		UniqueIdFactory.setFactory(new SingleAppUniqueIdFactory(true));
		MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
		f.defaultInitialization();
		DbRegistry.setConFactory(f);
		DbRegistry.setTablePrefix("stutst_");
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
		myDomain2MapperMapper.addMapping(GuestRole.class, RoleOutputMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   
		UoW.newCurrent();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		DbRegistry.getDbConnection().rollback();
		DbRegistry.closeDbConnectionIfNeeded();
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
		UserTDG.createTable();
		UserTDG.createUserRoleTable();
		UoW.getCurrent().commit();
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		try {
			try { UserTDG.dropTable(); } catch (Exception e){}
			try { UserTDG.dropUserRoleTable(); } catch (Exception e){}
			DbRegistry.getDbConnection().commit();
		} catch (Exception e){}
	}
	
	@Test
	public void makeSureUserRolesDontGetNuked() throws Exception{

		User u1 = UserFactory.createNew("sthiel", "sthiel", Arrays.asList(new IRole[] {new GuestRole()}));
		UoW.getCurrent().commit();
		UoW.newCurrent();
		User u = UserInputMapper.find(u1.getId());
		Assert.assertEquals(1, u.getRoles().size());
		UoW.getCurrent().commit();
		UoW.newCurrent();
		u = UserInputMapper.find(u1.getId());
		u.setPassword("fudge");
		UoW.getCurrent().registerDirty(u);
		UoW.getCurrent().commit();
		UoW.newCurrent();
		u = UserInputMapper.find(u1.getId());
		Assert.assertEquals(1, u.getRoles().size());		
	}
}
