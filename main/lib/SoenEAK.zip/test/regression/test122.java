package test.regression;

import java.sql.DriverManager;
import java.sql.ResultSet;

import junit.framework.Assert;

import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.service.MultiAppUniqueIdFactory;
import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.tdg.UniqueIdTableTDG;
import org.dsrg.soenea.service.tdg.finder.UniqueIdTableFinder;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class test122 {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			try {
				DbRegistry.closeDbConnectionIfNeeded();
			} catch (Exception e) {}
			try {
				DbRegistry.closeDbConnectionIfNeeded(UniqueIdTableTDG.CONNECTIONTYPEKEY);
			} catch (Exception e) {}			
			MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
			f.defaultInitialization();
			DbRegistry.setConFactory(UniqueIdTableTDG.CONNECTIONTYPEKEY, f);
			DbRegistry.setTablePrefix(UniqueIdTableTDG.CONNECTIONTYPEKEY, "stutst_");
			MapperFactory myDomain2MapperMapper = new MapperFactory();
			myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
			UniqueIdTableTDG.createTable();
			DbRegistry.closeDbConnection(UniqueIdTableTDG.CONNECTIONTYPEKEY);
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		try{
			UniqueIdTableTDG.dropTable();
		} catch (Exception e){}
		DbRegistry.closeDbConnectionIfNeeded(UniqueIdTableTDG.CONNECTIONTYPEKEY);
	}
	
	@Test
	public void testBadStoreAfterInitialSearch() throws Exception {
		UniqueIdTableTDG.insert("t1", "t2", 1);
		MultiAppUniqueIdFactory multiFactory1 = new MultiAppUniqueIdFactory(true) {
			@Override
			public int getLength(){
				return 5;
			}
		};

		UniqueIdFactory.setFactory(multiFactory1);
		
		UniqueIdFactory.getMaxId("t1", "t2");
		UniqueIdFactory.getMaxId("t1", "t2");
		UniqueIdFactory.getMaxId("t1", "t2");
		UniqueIdFactory.getMaxId("t1", "t2");
		Assert.assertEquals(6, UniqueIdFactory.getMaxId("t1", "t2"));
		ResultSet rs = UniqueIdTableFinder.find("t1", "t2");
		rs.next();
		Assert.assertEquals(6, rs.getInt(1));
		Assert.assertEquals(7, UniqueIdFactory.getMaxId("t1", "t2"));
		rs = UniqueIdTableFinder.find("t1", "t2");
		rs.next();
		Assert.assertEquals(11, rs.getInt(1));
		
	}
	
}
