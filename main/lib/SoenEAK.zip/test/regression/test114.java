package test.regression;

import java.util.LinkedList;
import java.util.List;

import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.UserFactory;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.tdg.UserTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class test114 {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
		f.defaultInitialization();
		DbRegistry.setConFactory(f);
		DbRegistry.setTablePrefix("stutst_");
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   
		UoW.newCurrent();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		DbRegistry.getDbConnection().rollback();
		DbRegistry.closeDbConnectionIfNeeded();
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
		UserTDG.createTable();
		UserTDG.createUserRoleTable();
		UoW.getCurrent().commit();
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		try {
			try { UserTDG.dropTable(); } catch (Exception e){}
			try { UserTDG.dropUserRoleTable(); } catch (Exception e){}
			DbRegistry.getDbConnection().commit();
		} catch (Exception e){}
	}
	
	@Test
	public void makeSureEqualityWorksWithNew() throws Exception{
		List<IRole> roles = new LinkedList<IRole>();
		UserFactory.createNew(3l, 1l, "sthiel", "pass", roles);
		IdentityMap.get(3l, User.class);
	}
}
