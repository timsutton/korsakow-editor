package test.regression;

import java.sql.DriverManager;

import junit.framework.Assert;

import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.service.MultiAppUniqueIdFactory;
import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.tdg.UniqueIdTableTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class test121 {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			try {
				DbRegistry.closeDbConnectionIfNeeded();
			} catch (Exception e) {}
			try {
				DbRegistry.closeDbConnectionIfNeeded(UniqueIdTableTDG.CONNECTIONTYPEKEY);
			} catch (Exception e) {}	
			MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
			f.defaultInitialization();
			DbRegistry.setConFactory(UniqueIdTableTDG.CONNECTIONTYPEKEY, f);
			DbRegistry.setTablePrefix(UniqueIdTableTDG.CONNECTIONTYPEKEY, "stutst_");
			MapperFactory myDomain2MapperMapper = new MapperFactory();
			myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
			UniqueIdTableTDG.createTable();
			DbRegistry.closeDbConnection(UniqueIdTableTDG.CONNECTIONTYPEKEY);
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		try{
			UniqueIdTableTDG.dropTable();
		} catch (Exception e){}
		try {
			DbRegistry.closeDbConnectionIfNeeded();
		} catch (Exception e) {}
		try {
			DbRegistry.closeDbConnectionIfNeeded(UniqueIdTableTDG.CONNECTIONTYPEKEY);
		} catch (Exception e) {}			
	}
	
	@Test
	public void testUseMultiAppUniqueIdFactoryAfterSettingUpRows() throws Exception {
		UniqueIdTableTDG.insert("t1", "t2", 1);
		MultiAppUniqueIdFactory multiFactory1 = new MultiAppUniqueIdFactory(true) {
			public int getLength(){
				return 1;
			}
		};
		
		UniqueIdFactory.setFactory(multiFactory1);
		
		Assert.assertEquals(2, UniqueIdFactory.getMaxId("t1", "t2"));
		Assert.assertEquals(3, UniqueIdFactory.getMaxId("t1", "t2"));
		
		MultiAppUniqueIdFactory multiFactory2 = new MultiAppUniqueIdFactory(true) {
			public int getLength(){
				return 1;
			}
		};
		
		UniqueIdFactory.setFactory(multiFactory2);
		Assert.assertEquals(4, UniqueIdFactory.getMaxId("t1", "t2"));
		Assert.assertEquals(5, UniqueIdFactory.getMaxId("t1", "t2"));		
		
	}
	
}
