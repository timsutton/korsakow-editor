package test.regression;

import junit.framework.Assert;

import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.Person;
import test.PersonFactory;
import test.PersonMapper;
import test.PersonProxy;
import test.PersonTDG;
import test.SubPersonProxy;

public class test126 {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
		f.defaultInitialization();
		DbRegistry.setConFactory(f);
		DbRegistry.setTablePrefix("stutst_");
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(Person.class, PersonMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   
		UoW.newCurrent();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		DbRegistry.getDbConnection().rollback();
		DbRegistry.closeDbConnectionIfNeeded();
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
		PersonTDG.createTable();
		PersonFactory.createNew(1, 1, new PersonProxy(1l), 19, "Alice");
		UoW.getCurrent().commit();
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		try {
			try { PersonTDG.dropTable(); } catch (Exception e){}
			DbRegistry.getDbConnection().commit();
		} catch (Exception e){}
	}
	
	@Test
	public void testAcceptSubclassofSubclassofDomainObjectProxy() throws Exception {
		SubPersonProxy spp = new SubPersonProxy(1l);
		try {
			UoW.getCurrent().registerClean(spp);
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}
	
}
