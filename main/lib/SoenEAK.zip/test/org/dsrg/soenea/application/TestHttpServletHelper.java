package test.org.dsrg.soenea.application;


import javax.servlet.http.HttpServletRequest;

import junit.framework.Assert;

import org.dsrg.soenea.application.servlet.dispatcher.HttpServletHelper;
import org.junit.Test;

public class TestHttpServletHelper
{
	@Test
	public void testGetAttribute()
	{
		final String REQ_KEY = "req_key";
		final String SESSION_KEY = "session_key";
		final String APP_KEY = "app_key";
		
		final Object REQ_VALUE = "" + Math.random();
		final Object SESSION_VALUE = "" + Math.random();
		final Object APP_VALUE = "" + Math.random();
		
		HttpServletRequest request = new MyHttpServletRequest();
		HttpServletHelper helper = new HttpServletHelper(request);
		
		helper.setRequestAttribute(REQ_KEY, REQ_VALUE);
		helper.setSessionAttribute(SESSION_KEY, SESSION_VALUE);
		helper.setApplicationAttribute(APP_KEY, APP_VALUE);
		
		Assert.assertEquals(REQ_VALUE, helper.getRequestAttribute(REQ_KEY));
		Assert.assertEquals(SESSION_VALUE, helper.getSessionAttribute(SESSION_KEY));
		Assert.assertEquals(APP_VALUE, helper.getApplicationAttribute(APP_KEY));
		
		Assert.assertEquals(REQ_VALUE, helper.getAttribute(REQ_KEY));
		Assert.assertEquals(SESSION_VALUE, helper.getAttribute(SESSION_KEY));
		Assert.assertEquals(APP_VALUE, helper.getAttribute(APP_KEY));

		Assert.assertEquals(null, helper.getSessionAttribute(REQ_KEY));
		Assert.assertEquals(null, helper.getApplicationAttribute(REQ_KEY));
		
		Assert.assertEquals(null, helper.getRequestAttribute(SESSION_KEY));
		Assert.assertEquals(null, helper.getApplicationAttribute(SESSION_KEY));
		
		Assert.assertEquals(null, helper.getRequestAttribute(APP_KEY));
		Assert.assertEquals(null, helper.getSessionAttribute(APP_KEY));
	}
}
