package test.org.dsrg.soenea.uow;

import junit.framework.Assert;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.ObjectRemovedException;
import org.dsrg.soenea.uow.UoW;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestIdentityMapChecksForChildren {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(Dog.class, PetOutputMapper.class);
		myDomain2MapperMapper.addMapping(Cat.class, PetOutputMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   
		UoW.newCurrent();
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
	}
	
	@Test
	public void makeSureIdentityMapFindsChildren() throws Exception{
		Pet p1 = new Dog(1l, 1, "Fido", 10);
		Pet p2 = new Cat(2l, 1, "Meowser", 10);
		Dog d1 = new Dog(3l, 1, "Rex", 42);
		Cat c1 = new Cat(4l, 1, "Monster", 100);
		
		UoW.getCurrent().registerClean(p1);
		UoW.getCurrent().registerClean(p2);
		UoW.getCurrent().registerClean(d1);
		UoW.getCurrent().registerClean(c1);		

		Assert.assertTrue(IdentityMap.has(1l, Dog.class));
		Assert.assertTrue(IdentityMap.has(2l, Cat.class));
		Assert.assertTrue(IdentityMap.has(1l, Pet.class));
		Assert.assertTrue(IdentityMap.has(2l, Pet.class));
		Assert.assertFalse(IdentityMap.has(1l, Cat.class));
		Assert.assertFalse(IdentityMap.has(2l, Dog.class));
		Assert.assertTrue(IdentityMap.has(3l, Pet.class));
		Assert.assertTrue(IdentityMap.has(4l, Pet.class));		
	}

	@Test
	public void makeSureIdentityMapFindsRemovedChildren() throws Exception{
		Pet p1 = new Dog(1l, 1, "Fido", 10);

		UoW.getCurrent().registerRemoved(p1);
		
		try {
			IdentityMap.has(1l, Pet.class);
			Assert.fail();
		} catch (ObjectRemovedException e) {
			Assert.assertTrue(e.getRemovedObject().getId().equals(1l));
		}
		
		try {
			IdentityMap.has(1l, Dog.class);
			Assert.fail();
		} catch (ObjectRemovedException e) {
			Assert.assertTrue(e.getRemovedObject().getId().equals(1l));
		}
		
		try {
			Assert.assertFalse(IdentityMap.has(1l, Cat.class));
		} catch (ObjectRemovedException e) {
			Assert.fail();
		}
	}
}

abstract class Pet extends DomainObject<Long> {

	String name;
	
	protected Pet(Long id, long version, String name) {
		super(id, version);
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

class Dog extends Pet {

	int frisbeesCaught;

	public Dog(Long id, long version, String name, int frisbeesCaught) {
		super(id, version, name);
		this.frisbeesCaught = frisbeesCaught;
	}

	public int getFrisbeesCaught() {
		return frisbeesCaught;
	}

	public void setFrisbeesCaught(int frisbeesCaught) {
		this.frisbeesCaught = frisbeesCaught;
	}
}

class Cat extends Pet {

	int couchesScratched;
	
	public Cat(Long id, long version, String name, int couchesScratched) {
		super(id, version, name);
		this.couchesScratched = couchesScratched;
	}

	public int getCouchesScratched() {
		return couchesScratched;
	}

	public void setCouchesScratched(int couchesScratched) {
		this.couchesScratched = couchesScratched;
	}
}

class PetOutputMapper implements GenericOutputMapper<Long, Pet> {

	public void delete(Pet d) throws MapperException {}

	public void insert(Pet d) throws MapperException {}

	public void update(Pet d) throws MapperException {}
}


