package test.org.dsrg.soenea.uow;

import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.mapper.DomainObjectNotFoundException;
import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.service.DerbyConnectionFactory;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.ObjectRemovedException;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.DeleteDir;
import test.Person;
import test.PersonMapper;
import test.PersonProxy;
import test.PersonTDG;
import test.org.dsrg.soenea.domain.TestDomainObject;

public class TestProxyUnitOfWork
{
	static Person Alice = null;
	PersonProxy aliceProxy;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			DbRegistry.closeDbConnectionIfNeeded();
		} catch (Exception e) {}
		try {
			DriverManager.getConnection("jdbc:derby:;shutdown=true");
		} catch (Exception e) {}		
		if(!DeleteDir.deleteDirectory(new File("test_db"))) throw new IOException("Problem removing Derby database file structure");
		DbRegistry.setConFactory(new DerbyConnectionFactory(new File("test_db").getCanonicalPath()));
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(Person.class, PersonMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   
		UoW.newCurrent();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		//DbRegistry.getDbConnection().rollback();
		try {DbRegistry.closeDbConnectionIfNeeded();} catch (Exception e) {}
		try {
			DriverManager.getConnection("jdbc:derby:;shutdown=true");
		} catch (SQLException e){/* It's okay, apparently Derby always throws an exception when you kill it this way! */}
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
		PersonTDG.createTable();
		UoW.getCurrent().commit();
		UoW.newCurrent();
		aliceProxy = new PersonProxy(TestDomainObject.ALICE_ID);
	}

	@After
	public void tearDown() throws Exception {
		try {
			PersonTDG.dropTable();
			DbRegistry.getDbConnection().commit();
		} catch (Exception e){}
	}
	
	public void addAlice() throws Exception{

		Alice = new Person(TestDomainObject.ALICE_ID, new PersonProxy(TestDomainObject.BOB_ID), TestDomainObject.ALICE_AGE, TestDomainObject.ALICE_NAME);
		UoW.getCurrent().registerNew(Alice);
		//When instantiating a person, it automatically registers them as a new object with the UoW
		
		try {
			UoW.getCurrent().commit();
		} catch (Exception e) {
		}
		UoW.newCurrent();
		DbRegistry.closeDbConnection();
	}

	@Test
	public void testRegisterCleanProxy() {
		
		try {
		addAlice();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		UoW.getCurrent().registerClean(aliceProxy);
		Person checkAlice = null;
		try
		{
			Person testAlice = IdentityMap.get(TestDomainObject.ALICE_ID, Alice.getClass() );
			Assert.assertNotNull(testAlice);
			UoW.getCurrent().commit();
			
			checkAlice =  PersonMapper.find(TestDomainObject.ALICE_ID);
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		//Check to see if Alice changed at all, which she shouldn't have
		Assert.assertTrue(checkAlice.getName() == aliceProxy.getName());
		Assert.assertTrue(checkAlice.getAge() == aliceProxy.getAge());
		Assert.assertTrue(checkAlice.getId() == aliceProxy.getId());
		Assert.assertTrue(checkAlice.getVersion() == aliceProxy.getVersion());

	}
	
	@Test
	public void testRegisterDirtyProxy() {
		
		try {
			addAlice();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		aliceProxy.setAge( 1 + TestDomainObject.ALICE_AGE);
		
		UoW.getCurrent().registerDirty(aliceProxy);
		Person checkAlice = null;
		
		try
		{
			Person testAlice = IdentityMap.get(TestDomainObject.ALICE_ID, Alice.getClass() );
			Assert.assertNotNull(testAlice);
			UoW.getCurrent().commit();
			
			checkAlice =  PersonMapper.find(TestDomainObject.ALICE_ID);
		}
		catch(Exception e)
		{
			Assert.fail();
		}

		//Check to see if Alice changed at all, which she should have .. but only her age
		Assert.assertTrue(checkAlice.getName() == aliceProxy.getName());
		Assert.assertFalse(checkAlice.getAge() == Alice.getAge());
		Assert.assertTrue(checkAlice.getAge() == aliceProxy.getAge());
		Assert.assertTrue(checkAlice.getId() == aliceProxy.getId());
		Assert.assertTrue(checkAlice.getVersion() == aliceProxy.getVersion());
	}
	

	@Test
	public void testRegisterRemovedProxy() {
		
		try {
			addAlice();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		UoW.getCurrent().registerRemoved(aliceProxy);
		
		Person testAlice = null;
		try
		{
			testAlice = IdentityMap.get(TestDomainObject.ALICE_ID, Alice.getClass() );
			//We should still find aliceProxy in the identity map since it is in the unit of work in the "removed" list.
			// However, the UoW's hasDomainObject does NOT consider those in the removed list, 
			// so we must expect it to throw the exception
			
			Assert.fail("Alice not removed");
		} catch (ObjectRemovedException e) { //That's ok, she should have been removed.
		} catch(Exception e ) {
			Assert.fail();
		}
		
		Assert.assertNull(testAlice);
		
		try
		{
			UoW.getCurrent().commit();
		}
		catch(Exception e)
		{ e.printStackTrace();}
		

		try
		{
			PersonMapper.find(TestDomainObject.ALICE_ID);
			Assert.fail("Alice found");
		}
		catch(DomainObjectCreationException e)
		{
			Assert.assertTrue(true);
		}
		catch(Exception e)
		{
			Assert.fail();
		}
	}
	
	@Test
	public void testRegisterDirty_ObjectAndProxy()
	{
		UoW.getCurrent().registerDirty(Alice);
		
		//Here we are going to increment the proxy's age... this should go to the identity map
		// and retrieve the real Alice in memory as the proxy's internal object.
		Assert.assertTrue(Alice.getAge() == aliceProxy.getAge());
		aliceProxy.setAge(TestDomainObject.ALICE_AGE + 1);
		Assert.assertTrue(Alice.getAge() == aliceProxy.getAge());

		UoW.getCurrent().registerDirty(aliceProxy);
		
		Person checkAlice = null;
		try {
			checkAlice = IdentityMap.get(TestDomainObject.ALICE_ID, Person.class);
		} catch (DomainObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectRemovedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertTrue( checkAlice.getAge() == Alice.getAge() 
						&& checkAlice.getAge() == aliceProxy.getAge()
						&& checkAlice.getAge() != TestDomainObject.ALICE_AGE);
	}

	
	
}
