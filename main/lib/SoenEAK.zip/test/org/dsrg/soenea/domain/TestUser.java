package test.org.dsrg.soenea.domain;


import java.util.LinkedList;
import java.util.List;

import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.role.impl.GuestRole;
import org.dsrg.soenea.domain.role.mapper.RoleOutputMapper;
import org.dsrg.soenea.domain.user.IUser;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.UserFactory;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestUser {
	
	@BeforeClass
	public static void setupClass() throws Exception {
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
		myDomain2MapperMapper.addMapping(GuestRole.class, RoleOutputMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);
	}
	
	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		UoW.newCurrent();
	}

	@Test
	public void testRoleAssignment() throws Exception {
		List<IRole> roles = new LinkedList<IRole>();
		IUser u1 = UserFactory.createClean(1, 1, "Stuart", roles); 
		Assert.assertTrue(!u1.hasRole(GuestRole.class));		
		roles.add(new GuestRole());
		Assert.assertTrue(u1.hasRole(GuestRole.class));
	}

	
	
}
