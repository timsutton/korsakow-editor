package test.org.dsrg.soenea.domain;


import org.dsrg.soenea.domain.MetaDomainObject;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.Person;
import test.PersonProxy;
import test.UoWPerson;
import test.UoWPersonMapper;

public class TestUoWDomainObject {
	public static final long ALICE_ID = 1;
	public static final int ALICE_AGE = 25;
	public static final String ALICE_NAME = "Alice";
	public static final long BOB_ID = 2;
	public static final int BOB_AGE = 24;
	public static final String BOB_NAME = "Bob";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			MapperFactory myDomain2MapperMapper = new MapperFactory();
			myDomain2MapperMapper.addMapping(UoWPerson.class, UoWPersonMapper.class);
			UoW.initMapperFactory(myDomain2MapperMapper);   

		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		UoW.newCurrent();
	}

	@Test
	public void testDOToDOEquality() {
		UoWPerson Alice = new UoWPerson(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		UoWPerson Alice2 = new UoWPerson(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		Assert.assertTrue(Alice.equals(Alice2));
	}
	
	@Test
	public void testDOToMDOEquality() {
		Person Alice = new Person(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		MetaDomainObject<Long, Person> Alice2 = new MetaDomainObject<Long, Person>(Person.class, ALICE_ID);
		Assert.assertTrue(Alice.equals(Alice2));
	}
	
	@Test
	public void testMDOToDOEquality() {
		Person Alice = new Person(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		MetaDomainObject<Long, Person> Alice2 = new MetaDomainObject<Long, Person>(Person.class, ALICE_ID);
		Assert.assertTrue(Alice2.equals(Alice));
	}
	
	@Test
	public void testMDOToMDOEquality() {
		MetaDomainObject<Long, Person> Alice = new MetaDomainObject<Long, Person>(Person.class, ALICE_ID);
		MetaDomainObject<Long, Person> Alice2 = new MetaDomainObject<Long, Person>(Person.class, ALICE_ID);
		Assert.assertTrue(Alice2.equals(Alice));
	}
	
	@Test
	public void testDOToDONotEquality() {
		Person Alice = new Person(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		Person Bob = new Person(BOB_ID, new PersonProxy(ALICE_ID), BOB_AGE, BOB_NAME);
		Assert.assertTrue(!Alice.equals(Bob));
	}
	
	@Test
	public void testDOToMDONotEquality() {
		Person Alice = new Person(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		MetaDomainObject<Long, Person> Bob = new MetaDomainObject<Long, Person>(Person.class, BOB_ID);
		Assert.assertTrue(!Alice.equals(Bob));
	}
	
	@Test
	public void testMDOToDONotEquality() {
		Person Alice = new Person(ALICE_ID, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		MetaDomainObject<Long, Person> Bob = new MetaDomainObject<Long, Person>(Person.class, BOB_ID);
		Assert.assertTrue(!Bob.equals(Alice));
	}
	
	@Test
	public void testMDOToMDONotEquality() {
		MetaDomainObject<Long, Person> Alice = new MetaDomainObject<Long, Person>(Person.class, ALICE_ID);
		MetaDomainObject<Long, Person> Bob = new MetaDomainObject<Long, Person>(Person.class, BOB_ID);
		Assert.assertTrue(!Bob.equals(Alice));
	}
	
	
	
}
