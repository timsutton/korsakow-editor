package test.org.dsrg.soenea.domain;

import static test.org.dsrg.soenea.domain.TestDomainObject.*;

import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.Person;
import test.PersonFactory;
import test.PersonMapper;
import test.PersonProxy;

public class TestIdentityMap {
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			MapperFactory myDomain2MapperMapper = new MapperFactory();
			myDomain2MapperMapper.addMapping(Person.class, PersonMapper.class);
			UoW.initMapperFactory(myDomain2MapperMapper);   

		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
	}

	@After
	public void tearDown() throws Exception {
		UoW.newCurrent();
	}
	
	
	@Test
	public void testCanFindAlice() throws Exception{
		Person Alice = PersonFactory.createNew(ALICE_ID, 1l, new PersonProxy(BOB_ID), ALICE_AGE, ALICE_NAME);
		Assert.assertTrue(IdentityMap.has(ALICE_ID, Person.class));
		Assert.assertTrue(Alice.equals(IdentityMap.get(ALICE_ID, Person.class)));
	}
	
	@Test
	public void testCannotFindAliceAfterNewCurrent() throws Exception{
		testCanFindAlice();
		UoW.newCurrent();
		Assert.assertFalse(IdentityMap.has(ALICE_ID, Person.class));
	}
	
	@Test
	public void testCannotFindNonInstantiatedProxy() throws Exception{
		testCanFindAlice();
		Assert.assertFalse(IdentityMap.has(BOB_ID, Person.class));
	}

}
