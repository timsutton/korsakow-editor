package test.org.dsrg.soenea.service;


import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.service.DerbyConnectionFactory;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import test.DeleteDir;
import test.Person;
import test.PersonProxy;
import test.PersonTDG_MultiConn;

public class TestDBRegistryMultiConn {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		if(!DeleteDir.deleteDirectory(new File("FirstConnectionDB"))) throw new IOException("Problem removing Derby database file structure");
		if(!DeleteDir.deleteDirectory(new File("SecondConnectionDB"))) throw new IOException("Problem removing Derby database file structure");
		DbRegistry.setConFactory("Conn1",new DerbyConnectionFactory(new File("FirstConnectionDB").getCanonicalPath()));
		DbRegistry.setConFactory("Conn2", new DerbyConnectionFactory(new File("SecondConnectionDB").getCanonicalPath()));
		
		PersonTDG_MultiConn.createTable("Conn1");
		PersonTDG_MultiConn.createTable("Conn2");
	}

	@Test
	public void testConnections() throws SQLException {
		PersonTDG_MultiConn.insert(100, 1, 101, "Jeff", 23, "Conn1");
		PersonTDG_MultiConn.insert(200, 1, 101, "Mary", 23, "Conn2");

		PersonTDG_MultiConn.find(100, "Conn1");
		Person first = getPerson(PersonTDG_MultiConn.find(100, "Conn1"));
		Person second = getPerson(PersonTDG_MultiConn.find(200, "Conn2"));

		Assert.assertTrue(first.getId()== 100);
		Assert.assertTrue(second.getId() == 200);

		try
		{
			first = getPerson(PersonTDG_MultiConn.find(200, "Conn1"));
		}
		catch(SQLException e)
		{
			Assert.assertTrue("SQLException1",true);
		}

		try
		{
			first = getPerson(PersonTDG_MultiConn.find(100, "Conn2"));
		}
		catch(SQLException e)
		{
			Assert.assertTrue("SQLException2",true);
		}
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		DbRegistry.getDbConnection("Conn1").rollback();
		DbRegistry.getDbConnection("Conn2").rollback();
		DbRegistry.closeDbConnection("Conn1");
		DbRegistry.closeDbConnection("Conn2");
		try {
			DriverManager.getConnection("jdbc:derby:;shutdown=true");
		} catch (SQLException e){/* It's okay, apparently Derby always throws an exception when you kill it this way! */}
	}

	@After
	public void tearDown() throws Exception {
		try {
			DbRegistry.getDbConnection().rollback();
			DbRegistry.closeDbConnectionIfNeeded();
		} catch (Exception e){}
	}
	
	private static Person getPerson(ResultSet rs) throws SQLException {
		if(!rs.next())
			return null;

		return new Person(rs.getLong("id"), 
				rs.getLong("version"), 
				new PersonProxy(rs.getLong("buddy_id")),
				rs.getInt("age"),
				rs.getString("name").trim());
	}

}
