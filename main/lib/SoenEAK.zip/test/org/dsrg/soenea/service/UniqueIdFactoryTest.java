package test.org.dsrg.soenea.service;

import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.service.DerbyConnectionFactory;
import org.dsrg.soenea.service.MultiAppUniqueIdFactory;
import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.tdg.UniqueIdTableTDG;
import org.dsrg.soenea.service.tdg.finder.UniqueIdTableFinder;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.DeleteDir;

/**
 * This is currently a test to ensure that SingleAppUniqueIdFactory and UniqueIdFactory are fully functional.
 * To be inserted in the future is a test to ensure that MultiAppUniqueIdFactory is functional. Note that this test
 * requires the use of a MySQL database.
 * @author user
 *
 */
public class UniqueIdFactoryTest {
	
	private static String table;
	private static String field;
	private static long currentMaxId;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		if(!DeleteDir.deleteDirectory(new File("test_db"))) throw new IOException("Problem removing Derby database file structure");
		DerbyConnectionFactory multi = new DerbyConnectionFactory(new File("test_db").getCanonicalPath());
		DerbyConnectionFactory single = new DerbyConnectionFactory(new File("test_db").getCanonicalPath());
		multi.defaultInitialization();
		single.defaultInitialization();
		DbRegistry.setConFactory(UniqueIdTableTDG.CONNECTIONTYPEKEY, multi);
		DbRegistry.setTablePrefix(UniqueIdTableTDG.CONNECTIONTYPEKEY, "");
		DbRegistry.setConFactory(single);
		DbRegistry.setTablePrefix("");

		// Table might have been left from previous run: try to drop it
		try {
			UniqueIdTableTDG.dropTable();
		} catch (SQLException e) {
			// Assume that this is because the table exists.
		}
		UniqueIdTableTDG.createTable();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		try{
			//try{DbRegistry.closeDbConnectionIfNeeded(UniqueIdTableTDG.CONNECTIONTYPEKEY);} catch (Exception e) {}
			//try{DbRegistry.closeDbConnectionIfNeeded();} catch (Exception e) {}
			
			try {
				DriverManager.getConnection("jdbc:derby:;shutdown=true");
			} catch (SQLException e){/* It's okay, apparently Derby always throws an exception when you kill it this way! */}
		} catch (Exception e){e.printStackTrace();}
	} 

	@Before
	public void setUp() throws Exception {
		table = "tableName"+Math.random();
		field = "fieldName"+Math.random();
		currentMaxId = (int)(Math.random()*1000);
		UniqueIdTableTDG.insert(table, field, currentMaxId);
		//DbRegistry.closeDbConnectionIfNeeded();
	}

	@After
	public void tearDown() throws Exception {
		try {
			UniqueIdTableTDG.delete(table,field);
		} catch (Exception e){}
	}
	
	/**
	 * This is also a test for the default behaviour of UniqueIdFactory
	 * @throws SQLException 
	 */
	@Test
	public void testSingleAppUniqueIdFactory() throws SQLException {
		ResultSet rs = UniqueIdTableFinder.findAll();
		if(rs.next()){
			Assert.assertTrue(rs.getString("tableName").equalsIgnoreCase(table));
			Assert.assertTrue(rs.getString("fieldName").equalsIgnoreCase(field));
			Assert.assertTrue(rs.getLong("currentMaxId") == currentMaxId);
		}
		Assert.assertFalse(rs.next());
		Assert.assertTrue((currentMaxId+1) == UniqueIdFactory.getMaxId(UniqueIdTableTDG.TABLE_NAME, "currentMaxId"));
		DbRegistry.closeDbConnectionIfNeeded();
	}
	
	@Test
	public void testMultiAppUniqueIdFactory() throws SQLException {
		UniqueIdFactory.setFactory((UniqueIdFactory)(new MultiAppUniqueIdFactory()));
		ResultSet rs = UniqueIdTableFinder.findAll();
		if(rs.next()){
			Assert.assertTrue(rs.getString("tableName").equalsIgnoreCase(table));
			Assert.assertTrue(rs.getString("fieldName").equalsIgnoreCase(field));
			Assert.assertTrue(rs.getLong("currentMaxId") == currentMaxId);
		}
		Assert.assertFalse(rs.next());
		Assert.assertTrue((currentMaxId + 1) == UniqueIdFactory.getMaxId(table, field));
	}
	
}
