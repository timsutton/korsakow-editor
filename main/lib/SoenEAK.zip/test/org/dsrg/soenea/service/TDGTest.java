package test.org.dsrg.soenea.service;

import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.dsrg.soenea.domain.MetaDomainObject;
import org.dsrg.soenea.service.DerbyConnectionFactory;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import test.DeleteDir;
import test.Person;
import test.PersonMapper;
import test.PersonProxy;
import test.PersonTDG;
import test.org.dsrg.soenea.domain.TestDomainObject;

public class TDGTest {
	
	Person Alice = null;
	MetaDomainObject<Long, Person> AliceMDO = null;
	MetaDomainObject<Long, Person> BobMDO = null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			if(!DeleteDir.deleteDirectory(new File("test_db"))) throw new IOException("Problem removing Derby database file structure");
			DbRegistry.setConFactory(new DerbyConnectionFactory(new File("test_db").getCanonicalPath()));
			MapperFactory myDomain2MapperMapper = new MapperFactory();
			myDomain2MapperMapper.addMapping(Person.class, PersonMapper.class);
			UoW.initMapperFactory(myDomain2MapperMapper);   
			UoW.newCurrent();
	
			PersonTDG.createTable();
			UoW.getCurrent().commit();
			DbRegistry.closeDbConnection();
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		try{
			UoW.getCurrent().commit();
			DbRegistry.getDbConnection().rollback();
			DbRegistry.closeDbConnectionIfNeeded();
		} catch (Exception e){e.printStackTrace();}
		try {
			DriverManager.getConnection("jdbc:derby:;shutdown=true");
		} catch (SQLException e){/* It's okay, apparently Derby always throws an exception when you kill it this way! */}
	}

	@Before
	public void setUp() throws Exception {
		UoW.newCurrent();
		Alice = new Person(TestDomainObject.ALICE_ID, new PersonProxy(TestDomainObject.BOB_ID), TestDomainObject.ALICE_AGE, TestDomainObject.ALICE_NAME);
		UoW.getCurrent().registerNew(Alice);
		BobMDO = new MetaDomainObject<Long, Person>(Person.class, TestDomainObject.BOB_ID);
		AliceMDO = new MetaDomainObject<Long, Person>(Person.class, TestDomainObject.ALICE_ID);
	}

	@After
	public void tearDown() throws Exception {

	}
	
	@Test
	public void testVersionIncreases() throws Exception {
		UoW.getCurrent().commit();
		UoW.newCurrent();
		Person p = PersonMapper.find(TestDomainObject.ALICE_ID);
		p.setName("Alice2");
		long version = p.getVersion();
		UoW.getCurrent().registerDirty(p);
		UoW.getCurrent().commit();
		UoW.newCurrent();
		p = PersonMapper.find(TestDomainObject.ALICE_ID);
		Assert.assertNotSame(version, p.getVersion());
	}
	
}
