package test.org.dsrg.soenea.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.mapper.UserInputMapper;
import org.dsrg.soenea.domain.user.mapper.UserOutputMapper;
import org.dsrg.soenea.service.MySQLConnectionFactory;
import org.dsrg.soenea.service.tdg.UserTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.uow.MapperFactory;
import org.dsrg.soenea.uow.UoW;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * This tests needs a MySQL database or something compatible. Derby doesn't like my toys :\
 * 
 * Some day the create table syntax will be db specific and I won't have to worry.
 * 
 * @author sthiel
 *
 */
public class UserTest {
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			MySQLConnectionFactory f = new MySQLConnectionFactory(null, null, null, null);
			f.defaultInitialization();
		DbRegistry.setConFactory(f);
		DbRegistry.setTablePrefix("stutst_");
		MapperFactory myDomain2MapperMapper = new MapperFactory();
		myDomain2MapperMapper.addMapping(User.class, UserOutputMapper.class);
		UoW.initMapperFactory(myDomain2MapperMapper);   		
		UoW.newCurrent();
		UserTDG.createTable();
		UserTDG.createUserRoleTable();
		UoW.getCurrent().commit();
		DbRegistry.closeDbConnection();
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		try{
			UserTDG.dropTable();
			UserTDG.dropUserRoleTable();
		} catch (Exception e){}
		UoW.getCurrent().commit();
		DbRegistry.closeDbConnectionIfNeeded();
	}

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {

	}
	
	/**
	 * This is for #61 It needs a MySQL compatible database to test against because of how UserTDG's SQL is written
	 * @throws MapperException 
	 * @throws SQLException 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testPasswordChangesAppropriatelyInDB() throws MapperException, SQLException {
		User meghan = new User(1, "Meghan", Collections.EMPTY_LIST);
		meghan.setPassword("surprise");
		new UserOutputMapper().insert(meghan);
		ResultSet rs = DbRegistry.getDbConnection().createStatement().executeQuery("SELECT password from " + UserTDG.USER_TABLE);
		rs.next();
		String oldpass = rs.getString("password");
		rs.close();

		meghan = UserInputMapper.find("Meghan");
		new UserOutputMapper().update(meghan);
		rs = DbRegistry.getDbConnection().createStatement().executeQuery("SELECT password from " + UserTDG.USER_TABLE);
		rs.next();
		Assert.assertEquals(oldpass, rs.getString("password"));
		rs.close();

		meghan.setPassword("fruitbat");
		rs = DbRegistry.getDbConnection().createStatement().executeQuery("SELECT password from " + UserTDG.USER_TABLE);
		rs.next();
		Assert.assertNotSame(oldpass, rs.getString("password"));
		rs.close();
		UoW.newCurrent();
	}
	
}
