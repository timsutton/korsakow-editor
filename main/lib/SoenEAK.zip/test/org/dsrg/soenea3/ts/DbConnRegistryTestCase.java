package test.org.dsrg.soenea3.ts;

import java.sql.Connection;
import java.util.MissingResourceException;

import junit.framework.TestCase;

import org.dsrg.soenea3.ts.ApplicationConfigRegistry;
import org.dsrg.soenea3.ts.DbConnRegistry;
import org.dsrg.soenea3.ts.TesterBackDoor;

/** The basic fixture for each test is that no connection exists. 
 */
public class DbConnRegistryTestCase extends TestCase {

	public void testIsNotConnected() throws Exception {
			assertTrue(!DbConnRegistry.isConnected());
	}

	public void testGetDbConnectionOk() throws Exception {
		// Ensure that the test properties file has been setup
		final String propertiesFile = "DbConnRegistry-Test";
		ApplicationConfigRegistry.setFileName(propertiesFile);
		try {
			ApplicationConfigRegistry.getUniqueInstance();			
		} catch (MissingResourceException e) {
			TesterBackDoor.resetApplicationConfigRegistry();
			fail("Properties file (" + propertiesFile + ") is missing for this test case.");
		}
		
		try {
			Connection dbConnection = DbConnRegistry.getDbConnection();
			assertNotNull(dbConnection);
			assertTrue("!isClosed", !dbConnection.isClosed());
			assertTrue("isConnected", DbConnRegistry.isConnected());
		} finally {
			DbConnRegistry.closeDbConnection();
			TesterBackDoor.resetApplicationConfigRegistry();
		}
	}

	public void testGetDbConnectionNoRegistry() throws Exception {
		ApplicationConfigRegistry.setFileName("this-file-does-not-exist");
		try {
			DbConnRegistry.getDbConnection();
			fail();
		} catch (Exception e) {
			// Assume that the test passed.
		} finally {
			DbConnRegistry.closeDbConnection(); // in case it was opened by mistake.
		}
	}

	public void testCloseDbConnection() throws Exception {
			DbConnRegistry.closeDbConnection();
	}

}
