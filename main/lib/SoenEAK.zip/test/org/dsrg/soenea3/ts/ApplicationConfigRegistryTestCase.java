package test.org.dsrg.soenea3.ts;

import java.util.MissingResourceException;

import junit.framework.TestCase;

import org.dsrg.soenea3.ts.ApplicationConfigRegistry;
import org.dsrg.soenea3.ts.NoSuchPropertyException;
import org.dsrg.soenea3.ts.TesterBackDoor;

public class ApplicationConfigRegistryTestCase extends TestCase {
	
	private static final String dneFileName = "39javlaij39javasao9j3ra";
	private static final String goodPropertyName = "propertyName";

	protected void setUp() throws Exception {
		TesterBackDoor.resetApplicationConfigRegistry();
		ApplicationConfigRegistry.setFileName("Test");
	}

	//@ signals (Exception) false;
	public void testGetRegistryOk() {
		try {
			ApplicationConfigRegistry.getUniqueInstance();
		} catch (Exception e) {
			fail("No exception expected but got: " + e);
		}
		assertTrue(true);
	}

	//@ signals (Exception) false;
	public void testGetRegistryNotOk() {
		ApplicationConfigRegistry.setFileName(dneFileName);
		try {
			ApplicationConfigRegistry.getUniqueInstance();
			fail("Properties file '" + dneFileName + "' should not exist.");
		} catch (MissingResourceException e) {
			assertTrue(true);
		}
	}
	
    // We cannot statically ensure that this tests passes.
	public void testGetPropertyOk() throws MissingResourceException, NoSuchPropertyException {
		String value = ApplicationConfigRegistry.getProperty(goodPropertyName);
		assertEquals(value, "propertyValue");
	}
	
	//@ signals (Exception) false;
	public void testGetPropertyNoRegistry() {
		ApplicationConfigRegistry.setFileName(dneFileName);
		try {
			String value = ApplicationConfigRegistry.getProperty(goodPropertyName);
			fail("Expecting an exception, not a property value of " + value);
		} catch (Exception e) {
			assertTrue(e instanceof MissingResourceException);
			//! assert e instanceof MissingResourceException; // cannot be proven
		}
	}
	
	//@ signals (Exception) false;
	public void testGetPropertyNoProperty() {
		String property = "propertyNameNotInPropertyFile";
		try {
			String value = ApplicationConfigRegistry.getProperty(property);
			fail("Expecting an exception, not a property value of " + value);
		} catch (Exception e) {
			assertTrue(e instanceof NoSuchPropertyException);
			//! assert e instanceof NoSuchPropertyException; // cannot be proven
		}
	}

}
