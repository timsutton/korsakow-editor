package test;

import java.io.File;

/**
 * Use with caution!!!!
 * 
 * I've written this before, several times. This time I grabbed from the web:
 * http://www.rgagnon.com/javadetails/java-0483.html
 * 
 * @author Stuart Thiel
 *
 */
public class DeleteDir {

	public static boolean deleteDirectory(File path) {
		if (path.exists()) {
			File[] files = path.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDirectory(files[i]);
				} else {
					files[i].delete();
				}
			}
		} else return true;
		return (path.delete());
	}
}