package test;

import org.dsrg.soenea.domain.UoWDomainObject;


public class UoWPerson extends UoWDomainObject<Long> implements IPerson {

	private IPerson buddy;
	private int age;
	private String name;
	
	public UoWPerson(IPerson buddy, int age, String name) {
		this(0, buddy, age, name);
	}
	
	public UoWPerson(long id, IPerson buddy, int age, String name) {
		this(id, 0, buddy, age, name);
	}
	
	public UoWPerson(long id, long version, IPerson buddy, int age, String name) {
		super(id, version);
		this.buddy = buddy;
		this.age = age;
		this.name = name;
	}
	
	public IPerson getBuddy() {
		return buddy;
	}

	public void setBuddy(IPerson buddy) {
		this.buddy = buddy;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	public int getCombinedAge() {
		return getAge()+buddy.getAge();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
