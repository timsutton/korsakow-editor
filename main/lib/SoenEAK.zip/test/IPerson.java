package test;

import org.dsrg.soenea.domain.interf.IDomainObject;

public interface IPerson extends IDomainObject<Long>{

	public abstract IPerson getBuddy();

	public abstract void setBuddy(IPerson buddy);

	public abstract int getAge();

	public abstract void setAge(int age);

	public abstract int getCombinedAge();

	public abstract String getName();

	public abstract void setName(String name);
	
	
}