package test;

import java.sql.SQLException;

public class UoWPersonFactory {

	
	public static UoWPerson createNew(IPerson buddy, int age, String name) throws SQLException {
		return createNew(PersonTDG.getMaxId(), 1, buddy, age, name);
	}
	
	public static UoWPerson createNew(long id, long version, IPerson buddy, int age, String name) throws SQLException {
		UoWPerson p = new UoWPerson(id, version, buddy, age, name);
		p.markNew();
		return p;
	}
	
	public static UoWPerson createClean(long id, long version, IPerson buddy, int age, String name) {
		UoWPerson p = new UoWPerson(id, version, buddy, age, name);
		p.markClean();
		return p;		
	}
}
