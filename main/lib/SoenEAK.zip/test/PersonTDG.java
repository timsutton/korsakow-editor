package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.threadLocal.DbRegistry;

public class PersonTDG {
	private static final String TABLE_NAME = "Person";
	private static final String CREATE_TABLE =
	 "CREATE TABLE " + TABLE_NAME + " ( " +
	 "id INTEGER, " +
	 "version INTEGER, " +
	 "buddy_id INTEGER, " +	 
	 "name CHAR(128), " +
	 "age INTEGER, " +
	 "PRIMARY KEY (id) " +
	 ")";
	private static final String DROP_TABLE = 
		"DROP TABLE " + TABLE_NAME;
	private static final String INSERT_SQL =
		"INSERT INTO " + TABLE_NAME + " VALUES (?, ?, ?, ?, ?)";
	private static final String UPDATE_SQL = 
		"UPDATE " + TABLE_NAME + " SET version=version+1, buddy_id=?, name=?, age=? " +
		"WHERE id = ? AND version = ?";
	private static final String DELETE_SQL = 
		"DELETE FROM " + TABLE_NAME + " WHERE id=? AND version=?";
	private static final String SELECT_SQL = 
		"SELECT id, version, buddy_id, name, age " +
		"FROM " + TABLE_NAME + " " +
		"WHERE id=?";
		
	
	public static int insert(long id, long version, long buddy_id, String name, int age) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(INSERT_SQL);
		ps.setLong(1, id);
		ps.setLong(2, version);
		ps.setLong(3, buddy_id);
		ps.setString(4, name);
		ps.setInt(5, age);		
		int count = ps.executeUpdate();
		ps.close();
		return count;
	}
	
	public static int update(long id, long version, long buddy_id, String name, int age) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(UPDATE_SQL);
		ps.setLong(1, buddy_id);
		ps.setString(2, name);
		ps.setInt(3, age);
		ps.setLong(4, id);
		ps.setLong(5, version);		
		int count = ps.executeUpdate();
		ps.close();
		return count;
	}
	
	public static int delete(long id, long version) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(DELETE_SQL);
		ps.setLong(1, id);
		ps.setLong(2, version);	
		int count = ps.executeUpdate();
		ps.close();
		return count;
	}
	
	public static ResultSet find(long id) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_SQL);
		ps.setLong(1, id);	
		return ps.executeQuery();		
	}
	
	public static void createTable() throws SQLException {
		DbRegistry.getDbConnection().createStatement().execute(CREATE_TABLE);
	}
	
	public static void dropTable() throws SQLException {
		try {
		DbRegistry.getDbConnection().createStatement().execute(DROP_TABLE);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static long getMaxId() throws SQLException {
		return UniqueIdFactory.getMaxId(TABLE_NAME, "id");
	}
	
}
