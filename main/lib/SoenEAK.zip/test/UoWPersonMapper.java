package test;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.mapper.DomainObjectNotFoundException;
import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.uow.ObjectRemovedException;


public class UoWPersonMapper implements GenericOutputMapper<Long, UoWPerson> {



	public void delete(UoWPerson d) throws MapperException {
		try {
			PersonTDG.delete(d.getId(), d.getVersion());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MapperException(e);
		}

	}

	public void insert(UoWPerson d) throws MapperException {
		try {
			PersonTDG.insert(d.getId(), d.getVersion(), d.getBuddy().getId(), d.getName(), d.getAge());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MapperException(e);
		}
	}

	public void update(UoWPerson d) throws MapperException {
		try {
			PersonTDG.update(d.getId(), d.getVersion(), d.getBuddy().getId(), d.getName(), d.getAge());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MapperException(e);
		}

	}

	public static UoWPerson find(long id) throws SQLException,
	DomainObjectCreationException {
		try {
			return IdentityMap.get(id, UoWPerson.class);
		} catch (DomainObjectNotFoundException e) {
		} catch (ObjectRemovedException e) {

		}
		return getPerson(PersonTDG.find(id));
	}

	private static UoWPerson getPerson(ResultSet rs) throws SQLException, DomainObjectCreationException {

		if(!rs.next()) throw new DomainObjectCreationException("No next row, it's not in here!");

		return UoWPersonFactory.createClean(rs.getLong("id"), 
				rs.getLong("version"), 
				new PersonProxy(rs.getLong("buddy_id")),
				rs.getInt("age"),
				rs.getString("name").trim());
	}
}
