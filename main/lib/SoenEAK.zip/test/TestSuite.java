package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import test.org.dsrg.soenea.domain.TestDomainObject;
import test.org.dsrg.soenea.domain.TestIdentityMap;
import test.org.dsrg.soenea.domain.TestUoWDomainObject;
import test.org.dsrg.soenea.domain.TestUser;
import test.org.dsrg.soenea.service.TDGTest;
import test.org.dsrg.soenea.service.TestDBRegistryMultiConn;
import test.org.dsrg.soenea.service.UniqueIdFactoryTest;
import test.org.dsrg.soenea.service.UserTest;
import test.org.dsrg.soenea.uow.TestIdentityMapChecksForChildren;
import test.org.dsrg.soenea.uow.TestProxyUnitOfWork;
import test.org.dsrg.soenea.uow.TestUoW;
import test.regression.test113;
import test.regression.test114;
import test.regression.test121;
import test.regression.test122;
import test.regression.test126;
import test.regression.test92;

@Suite.SuiteClasses( {
	//domain
	TestDomainObject.class,
	TestIdentityMap.class,
	TestUoWDomainObject.class,
	TestUser.class,
	//service
	TDGTest.class,
	TestDBRegistryMultiConn.class,
	UniqueIdFactoryTest.class,
	UserTest.class,
	//uow
	TestIdentityMapChecksForChildren.class,
	TestProxyUnitOfWork.class,
	TestUoW.class,
	//regression
	test92.class,
	test113.class,
	test114.class,
	test121.class,
	test122.class,
	test126.class,
})
@RunWith(Suite.class)
public class TestSuite {

}
