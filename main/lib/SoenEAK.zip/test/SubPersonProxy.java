package test;

public class SubPersonProxy extends PersonProxy {

	public SubPersonProxy(Long id) {
		super(id);
	}

}
