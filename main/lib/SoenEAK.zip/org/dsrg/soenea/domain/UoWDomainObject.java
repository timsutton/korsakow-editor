package org.dsrg.soenea.domain;

import org.dsrg.soenea.uow.UoW;

/**
 * @see DomainObject
 * This particular implementation also takes care of interactions with the Unit of Work pattern.
 */
public class UoWDomainObject<IDField> extends DomainObject<IDField> {

	protected UoWDomainObject(IDField id) {
		this(id, 0);
	}
	
	/**
	 * This is the constructor that should be called in the event of the creation of a persisted object. What should
	 * be passed is the id of the object, and it's most recent version number.
	 */
	
	protected UoWDomainObject(IDField id, long version) {
		super(id, version);
		if(UoW.isUsingUoW()) {
			if(version == 0) {
				UoW.getCurrent().registerNew(this);
				// Version = 0 means initialization, only a version of 1
				// should ever be stored.
				setVersion(1);
			}
			else UoW.getCurrent().registerClean(this);
		}
	}
	
	public void markDirty() {
		UoW.getCurrent().registerDirty(this);
	}

	public void markNew() {
		UoW.getCurrent().registerNew(this);
	}
	
	public void markClean() {
		UoW.getCurrent().registerClean(this);
	}

	public void markRemoved() {
		UoW.getCurrent().registerRemoved(this);
	}
	
}
