package org.dsrg.soenea.domain.command.impl;

import java.util.List;
import java.util.Vector;

import org.dsrg.soenea.domain.command.DomainCommand;
import org.dsrg.soenea.domain.helper.Helper;

public abstract class SessionCommand extends DomainCommand {

	private List<String> notifications;
	public static final String NOTIFICATION_ATTR = "notifications"; 
	
	public SessionCommand(Helper helper) {
		super(helper);
	}

	public void addNotification(String notification) {
		_getNotifications().add(notification);
	}
	
	public List<String> getNotifications() {
		return _getNotifications();
	}
	
	@SuppressWarnings("unchecked")
	private List<String> _getNotifications() {
		if(notifications == null) {
			notifications = (List<String>)helper.getRequestAttribute(NOTIFICATION_ATTR);
			if(notifications == null) {
				notifications = new Vector<String>();
				helper.setRequestAttribute(NOTIFICATION_ATTR, notifications);
			}
		}
		return notifications;
	}
}
