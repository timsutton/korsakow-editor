package org.dsrg.soenea.domain.command;

import org.dsrg.soenea.domain.helper.Helper;

/**
 * Domain commands are started by the dispatcher. The request carries the canonical class name which <br/>
 * causes the correct dispatcher for the desired command to be created by the dispatcher factory. <br/>
 * This Abstract Domain Command class simply enforces that all session commands must have the necessary <br/>
 * execute() method (and of course allows us to refer to its children abstractly) 
 *
 */

public abstract class DomainCommand {

	protected Helper helper;
	
	public DomainCommand(Helper helper) {
		this();
		this.helper = helper;
	}

	private DomainCommand(){}

	public abstract void execute() throws CommandException;
	
}
