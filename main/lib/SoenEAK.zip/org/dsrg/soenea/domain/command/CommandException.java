package org.dsrg.soenea.domain.command;

public class CommandException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3997969371948976476L;

	public CommandException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommandException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CommandException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CommandException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
