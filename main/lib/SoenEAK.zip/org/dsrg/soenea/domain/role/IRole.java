package org.dsrg.soenea.domain.role;

import org.dsrg.soenea.domain.interf.IDomainObject;

/**
 * An interface for roles. See IDomainObject Description.
 *
 */

public interface IRole extends IDomainObject<Long>{

	public abstract String getName();
	public abstract void setName(String name);

}