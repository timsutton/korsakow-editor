package org.dsrg.soenea.domain.role;

import java.util.HashMap;

import org.dsrg.soenea.service.PropertyRegistry;
import org.dsrg.soenea.service.Registry;
import org.dsrg.soenea.service.PropertyRegistry.PropertyInUseException;

/**
 * The Role factory class is used to create role instances. 
 *
 */
public abstract class RoleFactory {

	private static String propertyFile = "Myresources.properties";					//The properties file 
	private static String propertyName = "ConcreteRole_";							//The property prefix
	private static HashMap<Long, Role> roleRegistry = new HashMap<Long, Role>();	//The role registry
	
	//This is a static block which is "enforced" as the class is loading. In this case, it 
	// mentions this property is known as ConcreteRole_ in the property file.
	static {
		try {
			PropertyRegistry.registerProperty(propertyName, new PropertyRegistry.Property(propertyName, 
					"This property, appending a number (e.g. \"ConcreteRole_2\"), should look up a value that corresponds to the canonical class name of " +
					"a concrete subclase of the Role class.", propertyFile));
		} catch (PropertyInUseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * This method checks the role registry for the id and returns the appropriate role.
	 * If the ID is not found, it takes it out of the properties file and then puts it in the registry.
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static Role create(long id) throws Exception {
		Role r = roleRegistry.get(id);
		if(r == null) {
			String roleClass = Registry.getProperty(propertyName+id);
			r =  (Role)Class.forName(roleClass).newInstance();
			roleRegistry.put(id, r);
		}
		return r;
	}
}
