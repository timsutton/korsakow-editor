package org.dsrg.soenea.domain.role.mapper;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.role.Role;
import org.dsrg.soenea.domain.role.RoleFactory;
import org.dsrg.soenea.domain.user.IUser;
import org.dsrg.soenea.service.tdg.finder.UserFinder;

/**
 * The RoleInputMapper is responsible for returning a list of user roles object for a specific user from the database.
 *
 */

public class RoleInputMapper {

	/**
	 * This creates a list of IRoles for a passed User 
	 * 
	 * @param u A User for which to get the roles for
	 * @return A list of IRoles for the passed User
	 * @throws Exception
	 */
	public static List<IRole> find(IUser u) throws Exception {
		ResultSet rs = UserFinder.findRoleByUser(u.getId());
		List<IRole> l = new ArrayList<IRole>();
		while(rs.next()) {
			l.add(getRole(rs));
		}
		return l;
	}

	/**
	 * Uses the role factory to instantiate roles 
	 * using a result set "row".
	 * 
	 * @param rs A single "row" of a result set.
	 * @return Returns an instance of Role
	 * @throws Exception MissingResourceException
	 */
	private static Role getRole(ResultSet rs) throws Exception {
		return RoleFactory.create(rs.getLong("role_id"));
	}
}
