package org.dsrg.soenea.domain.role;

import org.dsrg.soenea.domain.DomainObject;


/**
 * This class is a domain object used to represent a possible role a user may have. This is simply framework
 * for having users with one or more roles. Users keep these roles in a list.
 * 
 * Initially implemented by David Reisch for the org.Code514.yp project and imported into SoenEA and modified by Stuart Thiel  
 * @author David Reisch
 * @author Stuart Thiel
 *
 */

public abstract class Role extends DomainObject<Long> implements IRole {
	
	private String name;
	
	/**
	 * 
	 * @param id The id of the role.
	 * @param version The current version of the role
	 * @param name The name of the role
	 */
	protected Role(Long id, long version, String name) {
		super(id,version);
		this.name = name;
	}
	
	//Note that we're currently not supporting versions, so we pass one. It's still in the Mapper is it's created, but it probably won't be.
	public Role(Long id, String name) {
		this(id, 1, name);
	}
	public String getName() {
		return this.name;
	}
	public String getCanonicalName() {
		return getClass().getPackage() + "." + getClass().getName() + "." + getName();   
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int hashCode() {
		return (IRole.class.getCanonicalName() + getId()).hashCode();
	}	
}
