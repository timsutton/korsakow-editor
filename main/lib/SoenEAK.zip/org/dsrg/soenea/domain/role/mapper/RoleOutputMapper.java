package org.dsrg.soenea.domain.role.mapper;

import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.domain.role.Role;


/**
 * This is a standard persistence mapper. It cascades all inserts, updates, and deletes to the roles associated with the given user.<br/>
 * Aside from that, it's standard.
 *
 */

public class RoleOutputMapper implements GenericOutputMapper<Long, Role>{

	/**
	 * Using this method to delete a user also deletes all of the users roles, maintaining consistency in your data store. 
	 */
	
	public void delete(Role d) throws MapperException {

	}

	public void insert(Role d) throws MapperException {

	}

	public void update(Role d) throws MapperException {


	}

}
