package org.dsrg.soenea.domain.role.impl;

import org.dsrg.soenea.domain.role.Role;

import org.dsrg.soenea.domain.role.IRole;

/**
 * This is a Guest Role which implements the IRole interface.
 *
 */
public class GuestRole extends Role implements IRole {

	private static final long GUEST_ROLE_ID = 1l;
	private static final String ROLE_NAME = "GuestRole";
	
	public GuestRole() {
		super(GUEST_ROLE_ID, 1, ROLE_NAME);
	}

	@Override
	public String getName() {
		return ROLE_NAME;
	}

	@Override
	public Long getId() {
		return GUEST_ROLE_ID;
	}

	@Override
	public long getVersion() {
		return 1;
	}

}
