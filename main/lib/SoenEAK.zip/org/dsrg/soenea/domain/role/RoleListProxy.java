package org.dsrg.soenea.domain.role;

import java.util.List;

import org.dsrg.soenea.domain.proxy.ListProxy;
import org.dsrg.soenea.domain.role.mapper.RoleInputMapper;
import org.dsrg.soenea.domain.user.IUser;

/**
 * When using proxies to lazy loading a list, there are two schools of thought: one can either have a list of <br/>
 * proxies or one can simply lazily load the entire list. In terms of roles, the latter is what RoleListProxy is for.<br/>
 *  
 * 
  */
public class RoleListProxy extends ListProxy<IRole>{

	private IUser owningUser;	//The internal information needed to find the list of roles in the database
	
	public RoleListProxy(IUser owningUser) {
		this.owningUser = owningUser;
	}
	
	@Override
	protected List<IRole> getActualList() throws Exception {
		return RoleInputMapper.find(owningUser);
	}

}
