package org.dsrg.soenea.domain;

public class MapperException extends Exception {

	private static final long serialVersionUID = -8496107547331725857L;

	public MapperException(String s) {
		super(s);
	}
	
	public MapperException(Throwable t) {
		super(t);
	}
	
	public MapperException(String s, Throwable t) {
		super(s, t);
	}
	
	
}
