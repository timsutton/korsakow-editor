package org.dsrg.soenea.domain.proxy;

import java.sql.SQLException;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.interf.IDomainObject;

/**
 * This abstract class refactors out the common Proxy code found in all this framework's
 * Domain Object Proxies. It relies on the fact that the subclassing Proxy will
 * implement a method that can appropriately "map" a long id to a Domain Object of 
 * the appropriate type. 
 *
 * @author Stuart Thiel
 *
 * @param <DO> The Domain Object represented by this proxy.
 */
public abstract class DomainObjectProxy<IDField, DO extends DomainObject<IDField>> implements IDomainObject<IDField>{

	private IDField id;
	private DO innerObject;

	protected DomainObjectProxy(IDField id) {
		this.id = id;
	}
	
	protected abstract DO getFromMapper(IDField id) throws SQLException, DomainObjectCreationException;
	
	/**
	 * Grabs the innerObject, or if it hasn't been initialized yet,  
	 * calls a method that should be overridden to get that from the Mapper.
	 * 
	 * Is synchronized, so even if multiple threads were using the proxy, it should
	 * be safe. I don't know if the other pieces are safe, but the proxy itself is.
	 * 
	 * @return
	 */
	public synchronized DO getInnerObject() {
		if(innerObject==null)
			try {
				innerObject = getFromMapper(id);

			} catch (Exception e) {
				throw new ProxyException(e);
			}
		return innerObject;
	}
	
	public IDField getId() {
		return id;
	}

	public long getVersion() {
		return getInnerObject().getVersion();
	}
	public void setVersion(long new_version) {
		getInnerObject().setVersion(new_version);
	}
	
	@Override
	public boolean equals(Object o) {
		if(!(o instanceof IDomainObject)) return false;
		return getInnerObject().equals(o);		
	}
	
}
