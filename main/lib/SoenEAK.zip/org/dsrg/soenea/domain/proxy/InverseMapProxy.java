package org.dsrg.soenea.domain.proxy;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.dsrg.soenea.domain.interf.IDomainObject;
import org.dsrg.soenea.domain.proxy.ProxyException;


/**
 * All methods in this class are proxy implementations of the java.util.Map interface methods. As with all proxies, 
 * the actual map data is only loaded when needed.<br/>
 * As a result, every method call invokes the innerMap to perform it's action.
 * Thus innerMap must be implemented in any class that extends MapProxy.
 * 
 * Written by Steve Morse for the URS project.
 * Idea from the ListProxy written by Dave Reisch for the org.Code514.yp project.
 * 
 * @author Steve Morse
 *
 * @param <IDO,V>
 */
public abstract class InverseMapProxy<IDO extends IDomainObject<?>, V> implements Map<IDO,V> {
	private Map<IDO,V> innerMap;
	
	protected abstract Map<IDO,V> getActualMap() throws Exception;
	
	private synchronized Map<IDO,V> getInnerMap() {
		if(innerMap == null)
			try {
				innerMap = getActualMap();
			} catch (Exception e) {
				throw new ProxyException(e);
			}
		return innerMap;
	}

	public void clear() {
		getInnerMap().clear();
	}
	
	public boolean containsKey(IDO key) {
		return getInnerMap().containsKey(key);
	}
	
	public boolean containsValue(Object value) {
		return getInnerMap().containsValue(value);
	}

	public Set<Map.Entry<IDO,V>> entrySet() {
		return getInnerMap().entrySet();
	}
	
	public boolean equals(Object o) {
		return getInnerMap().equals(o);
	}
	
	public V get(IDO key) {
		return getInnerMap().get(key);
	}

	public int hashCode()	{
		return getInnerMap().hashCode();
	}
	
	public boolean isEmpty() {
		return getInnerMap().isEmpty();
	}
	
	public Set<IDO> keySet() {
		return getInnerMap().keySet();
	}
	
	public V put(IDO key, V value) {
		return getInnerMap().put(key, value);
	}

	public void putAll(Map<? extends IDO, ? extends V> map) {
		getInnerMap().putAll(map);
	}

	public V remove(Object key) {
		return getInnerMap().remove(key);
	}

	public int size() {
		return getInnerMap().size();
	}

	public Collection<V> values() {
		return getInnerMap().values();
	}
}
