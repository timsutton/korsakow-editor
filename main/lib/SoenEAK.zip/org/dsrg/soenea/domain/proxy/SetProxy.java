package org.dsrg.soenea.domain.proxy;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import org.dsrg.soenea.domain.interf.IDomainObject;

/**
 * Based on the approach by Dave Reisch in ListProxy.
 * 
 * @author Stuart Thiel
 *
 * @param <IDO> The Domain Object in the set.
 */
public abstract class SetProxy<IDO extends IDomainObject<?>> implements Set<IDO> {
	private Set<IDO> innerSet;
	
	protected abstract Set<IDO> getActualSet() throws Exception;
	
	private synchronized Set<IDO> getInnerSet() {
		if(innerSet==null)
			try {
				innerSet = getActualSet();
			} catch (Exception e) {
				throw new ProxyException(e);
			}
		return innerSet;
	}

	public boolean add(IDO e) {
		return getInnerSet().add(e);
	}

	public boolean addAll(Collection<? extends IDO> c) {
		return getInnerSet().addAll(c);
	}

	public void clear() {
		getInnerSet().clear();
	}

	public boolean contains(Object o) {
		return getInnerSet().contains(o);
	}

	public boolean containsAll(Collection<?> c) {
		return getInnerSet().containsAll(c);
	}

	public boolean isEmpty() {
		return getInnerSet().isEmpty();
	}

	public Iterator<IDO> iterator() {
		return getInnerSet().iterator();
	}

	public boolean remove(Object o) {
		return getInnerSet().remove(o);
	}

	public boolean removeAll(Collection<?> c) {
		return getInnerSet().removeAll(c);
	}

	public boolean retainAll(Collection<?> c) {
		return getInnerSet().retainAll(c);
	}

	public int size() {
		return getInnerSet().size();
	}

	public Object[] toArray() {
		return getInnerSet().toArray();
	}

	public <T> T[] toArray(T[] a) {
		return getInnerSet().toArray(a);
	}
}
