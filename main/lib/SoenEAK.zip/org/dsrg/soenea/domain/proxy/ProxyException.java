package org.dsrg.soenea.domain.proxy;

public class ProxyException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ProxyException(String s) {
		super(s);
	}
	
	public ProxyException(Throwable t) {
		super(t);
	}
	
	public ProxyException(String s, Throwable t) {
		super(s, t);
	}
	
}
