package org.dsrg.soenea.domain.proxy;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.dsrg.soenea.domain.interf.IDomainObject;
import org.dsrg.soenea.domain.proxy.ProxyException;


/**
 * All methods in this class are proxy implementations of the java.util.Map interface methods. As with all proxies, 
 * the actual map data is only loaded when needed.<br/>
 * As a result, every method call invokes the innerMap to perform it's action.
 * Thus innerMap must be implemented in any class that extends MapProxy.
 * 
 * Written by Steve Morse for the URS project.
 * Idea from the ListProxy written by Dave Reisch for the org.Code514.yp project.
 * 
 * @author Steve Morse
 *
 * @param <K,IDO>
 */
public abstract class MapProxy<K, IDO extends IDomainObject<?>> implements Map<K,IDO> {
	private Map<K,IDO> innerMap;
	
	protected abstract Map<K,IDO> getActualMap() throws Exception;
	
	private synchronized Map<K,IDO> getInnerMap() {
		if(innerMap == null)
			try {
				innerMap = getActualMap();
			} catch (Exception e) {
				throw new ProxyException(e);
			}
		return innerMap;
	}

	public void clear() {
		getInnerMap().clear();
	}

	public boolean containsKey(Object key) {
		return getInnerMap().containsKey(key);
	}
	
	public boolean containsValue(IDO value) {
		return getInnerMap().containsValue(value);
	}

	public Set<Map.Entry<K,IDO>> entrySet() {
		return getInnerMap().entrySet();
	}
	
	public boolean equals(Object o) {
		return getInnerMap().equals(o);
	}
	
	public IDO get(Object key) {
		return getInnerMap().get(key);
	}

	public int hashCode()	{
		return getInnerMap().hashCode();
	}
	
	public boolean isEmpty() {
		return getInnerMap().isEmpty();
	}
	
	public Set<K> keySet() {
		return getInnerMap().keySet();
	}
	
	public IDO put(K key, IDO value) {
		return getInnerMap().put(key, value);
	}

	public void putAll(Map<? extends K, ? extends IDO> map) {
		getInnerMap().putAll(map);
	}

	public IDO remove(Object key) {
		return getInnerMap().remove(key);
	}

	public int size() {
		return getInnerMap().size();
	}

	public Collection<IDO> values() {
		return getInnerMap().values();
	}
}
