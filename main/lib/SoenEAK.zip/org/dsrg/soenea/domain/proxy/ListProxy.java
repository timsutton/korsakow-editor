package org.dsrg.soenea.domain.proxy;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.dsrg.soenea.domain.interf.IDomainObject;

/**
 * All the methods in this class are implementations of the List methods. As with all proxies, the actual data is only loaded when needed.<br/>
 * As a result, every method call makes reference to the innerList, which is implemented in any class that extends ListProxy.
 * 
 * 
 * Written by Dave Reisch for the org.Code514.yp project.
 * 
 * @author Dave Reisch
 *
 * @param <IDO>
 */
public abstract class ListProxy<IDO extends IDomainObject<?>> implements List<IDO> {
	private List<IDO> innerList;
	
	protected abstract List<IDO> getActualList() throws Exception;
	
	private synchronized List<IDO> getInnerList() {
		if(innerList==null)
			try {
				innerList = getActualList();
			} catch (Exception e) {
				throw new ProxyException(e);
			}
		return innerList;
	}

	public boolean add(IDO o) {
		return getInnerList().add(o);
	}

	public void add(int index, IDO element) {
		getInnerList().add(index, element);
	}

	public boolean addAll(Collection<? extends IDO> c) {
		return getInnerList().addAll(c);
	}

	public boolean addAll(int index, Collection<? extends IDO> c) {
		return getInnerList().addAll(index, c);
	}

	public void clear() {
		getInnerList().clear();
	}

	public boolean contains(Object o) {
		return getInnerList().contains(o);
	}

	public boolean containsAll(Collection<?> c) {
		return getInnerList().containsAll(c);
	}

	public IDO get(int index) {
		return getInnerList().get(index);
	}

	public int indexOf(Object o) {
		return getInnerList().indexOf(o);
	}

	public boolean isEmpty() {
		return getInnerList().isEmpty();
	}

	public Iterator<IDO> iterator() {
		return getInnerList().iterator();
	}

	public int lastIndexOf(Object o) {
		return getInnerList().lastIndexOf(o);
	}

	public ListIterator<IDO> listIterator() {
		return getInnerList().listIterator();
	}

	public ListIterator<IDO> listIterator(int index) {
		return getInnerList().listIterator(index);
	}

	public boolean remove(Object o) {
		return getInnerList().remove(o);
	}

	public IDO remove(int index) {
		return getInnerList().remove(index);
	}

	public boolean removeAll(Collection<?> c) {
		return getInnerList().removeAll(c);
	}

	public boolean retainAll(Collection<?> c) {
		return getInnerList().retainAll(c);
	}

	public IDO set(int index, IDO element) {
		return getInnerList().set(index, element);
	}

	public int size() {
		return getInnerList().size();
	}

	public List<IDO> subList(int fromIndex, int toIndex) {
		return getInnerList().subList(fromIndex, toIndex);
	}

	public Object[] toArray() {
		return getInnerList().toArray();
	}

	public <T> T[] toArray(T[] a) {
		return getInnerList().toArray(a);
	}
	
	public String toString() {
		return getInnerList().toString();
	}
}
