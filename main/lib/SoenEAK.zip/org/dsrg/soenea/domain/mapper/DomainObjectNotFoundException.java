package org.dsrg.soenea.domain.mapper;

import org.dsrg.soenea.domain.MapperException;

public class DomainObjectNotFoundException extends MapperException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1018111422847514958L;

	public DomainObjectNotFoundException(String message) {
		super(message);
	}

	public DomainObjectNotFoundException(Throwable cause) {
		super(cause);
	}

	public DomainObjectNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
