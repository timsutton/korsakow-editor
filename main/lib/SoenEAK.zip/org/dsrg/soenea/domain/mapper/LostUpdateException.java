package org.dsrg.soenea.domain.mapper;

import org.dsrg.soenea.domain.MapperException;

public class LostUpdateException extends MapperException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3655921268354131339L;

	public LostUpdateException(String s) {
		super(s);
	}

	public LostUpdateException(Throwable t) {
		super(t);
	}

	public LostUpdateException(String s, Throwable t) {
		super(s, t);
	}

}
