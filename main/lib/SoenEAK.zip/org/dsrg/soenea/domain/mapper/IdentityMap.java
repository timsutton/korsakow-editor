package org.dsrg.soenea.domain.mapper;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.MetaDomainObject;
import org.dsrg.soenea.uow.ObjectRemovedException;
import org.dsrg.soenea.uow.UoW;

public class IdentityMap {
	/**
	 * The purpose is to use the Identity Map nature of the UoW to discover
	 * if there are any Domain Objects of the appropriate type that match
	 * the provided id. If they exist in the UoW, we return them.
	 * 
	 * 
	 * @param <DO> The Domain Object type that we're looking to find. 
	 * @param id
	 * @param innerClass
	 * @return A matching Domain Object from the UoW. Null is never returned. If
	 * it can't be found, an exception is thrown.
	 * @throws DomainObjectCreationException If the Domain Object can't be found in
	 * the UoW, we throw a DomainObjectCreationException.
	 * @throws ObjectRemovedException If the Domain Object can be found in the UoW,
	 * but only in the Removed List, then we throw this exception to indicate the 
	 * weirdness of trying to find something that you've already tried to delete.
	 * 
	 */
	public static <IDField, DO extends DomainObject<IDField>> DO get(IDField id, Class<DO> innerClass) 
	  throws DomainObjectNotFoundException, ObjectRemovedException{
		MetaDomainObject<IDField, DO> mdo = new MetaDomainObject<IDField, DO>(innerClass, id);
		if(UoW.getCurrent().hasDomainObjectRepresentedByMeta(mdo)) {
			return UoW.getCurrent().getObject(mdo);
		}
		throw new DomainObjectNotFoundException("Doesn't Exist");
	}
	
	public static <IDField, DO extends DomainObject<IDField>> boolean has(IDField id, Class<DO> innerClass) 
	  throws ObjectRemovedException {
		return UoW.getCurrent().hasDomainObjectRepresentedByMeta(new MetaDomainObject<IDField, DO>(innerClass, id));
	}
}
