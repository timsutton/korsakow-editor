package org.dsrg.soenea.domain.mapper;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.MapperException;

/**
 * The GenericOutputMapper provides an interface for all Output Mappers. 
 * @author Stuart Thiel
 *
 * @param <MappedObject>
 */
public interface GenericOutputMapper<IDField, MappedObject extends DomainObject<IDField>> {

	public abstract void insert(MappedObject d) throws MapperException;
	public abstract void update(MappedObject d) throws MapperException;
	public abstract void delete(MappedObject d) throws MapperException;
	
}