package org.dsrg.soenea.domain.helper;
/**
 * An interface that can be used to package Requests. See HttpServletRequestHelper.
 *
 */
public interface Helper {

	public abstract int getInt(String pName) throws NumberFormatException;

	public abstract long getLong(String pName) throws NumberFormatException;

	public abstract String getString(String pName);

	public abstract String[] getValues(String pName);

	public abstract boolean getBoolean(String pName);
	
	public abstract float getFloat(String pName);
	
	public abstract double getDouble(String pName);
	
	public abstract void setRequestAttribute(String key, Object value);

	public abstract Object getRequestAttribute(String key);	

	public abstract void setSessionAttribute(String key, Object value);

	public abstract Object getSessionAttribute(String key);
	
	public abstract String getSessionId();
	
	public abstract void setApplicationAttribute(String key, Object value);

	public abstract Object getApplicationAttribute(String key);
	
	/**
	 * Gets attributes in the following order:
	 * 	  -request
	 *    -session
	 *    -application
	 * @return null iff all the above returned null 
	 */
	public abstract Object getAttribute(String key);
}
