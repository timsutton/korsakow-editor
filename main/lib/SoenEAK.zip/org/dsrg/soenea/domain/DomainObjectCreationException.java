package org.dsrg.soenea.domain;

public class DomainObjectCreationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1188527692314463543L;

	public DomainObjectCreationException(String s) {
		super(s);
	}
	
	public DomainObjectCreationException(Throwable t) {
		super(t);
	}
	
	public DomainObjectCreationException(String s, Throwable t) {
		super(s, t);
	}
	
	
}
