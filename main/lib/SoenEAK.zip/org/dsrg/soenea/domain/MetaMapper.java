package org.dsrg.soenea.domain;

import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.environment.CreationException;
import org.dsrg.soenea.environment.KeyNotFoundException;
import org.dsrg.soenea.environment.ParameterizedFactory;
/**
 * This class is a mapper of mappers. Essentially, the Unit of Work contains a MetaMapper, and on commit(), insert, update and delete are called.<br/>
 * The actual DomainObject that is passed in each method call is handled by the MapperFactory.
 */
public class MetaMapper<ResourceType> {
	private ParameterizedFactory<DomainObject<?>, GenericOutputMapper<?, DomainObject<?>>, ResourceType> MapperFactory;
	
	public <IDField> void init(ParameterizedFactory<DomainObject<?>, GenericOutputMapper<?, DomainObject<?>>, ResourceType> f) {
		MapperFactory = f;
	}

	public void insert(DomainObject<?> d) throws KeyNotFoundException, CreationException, MapperException {
		MapperFactory.getInstance(d).insert(d);
	}

	public void update(DomainObject<?> d) throws KeyNotFoundException, CreationException, MapperException {
		MapperFactory.getInstance(d).update(d);
	}

	public void delete(DomainObject<?> d) throws KeyNotFoundException, CreationException, MapperException {
		MapperFactory.getInstance(d).delete(d);
	}
}
