package org.dsrg.soenea.domain;

import org.dsrg.soenea.domain.interf.IDomainObject;

/**
 * Every object used in a domain are domain objects, hence the use of this class.<br/>
 * Every object in the domain should be a subclass of this class.<br/>
 * The domain object pattern takes into account the id of an object, which in SoenEA can be created using<br/>
 * the UniqueIDFactory, and the version number of the object. ID tables work for unique ids too.<br/>
 */

public abstract class DomainObject<IDField> implements IDomainObject<IDField>{
	private IDField id;			//The id of the object. This should be unique
	private long version;		//The version of the object. This should be updated when the object is updated.
	
	/**
	 * This is the constructor that should be called in the event of the creation of a new object.
	 */
	
	protected DomainObject(IDField id) {
		this(id, 0);
	}
	
	/**
	 * This is the constructor that should be called in the event of the creation of a persisted object. What should
	 * be passed is the id of the object, and it's most recent version number.
	 */
	protected DomainObject(IDField id, long version) {
		this.id = id;
		this.version = version;
	}

	public IDField getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}
	
	public void setVersion(long version) {
		this.version = version;
	}
	
	/**
	 * Tricky question, but what happens if we compare things with different 
	 * versions, but the same ID? What do we do? For now, I'm leaving it as
	 * equal, and letting the concept of version be dealt with elsewhere.
	 * @param d
	 * @return
	 */
	public boolean equals(Object d) {
		if(d instanceof DomainObject<?>) return equals((DomainObject<?>)d);
		return d.equals(this);
	}
	
	public boolean equals(DomainObject<?> d) {
		return (d.getId().equals(getId()) && (getClass().isInstance(d) || d.getClass().isInstance(this)));
	}
}
