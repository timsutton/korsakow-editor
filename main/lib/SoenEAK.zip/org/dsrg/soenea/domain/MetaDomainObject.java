package org.dsrg.soenea.domain;

/**
 * The motivation for the use of the MetaDomainObject is to be able to check for equality.<br/>
 * By creating a MetaDomainObject with an ID and class type, you can then test for equality with an actual DomainObject.<br/>
 * This is similar to a proxy, in that it is a place holder, however it differs in that it can't return the actual instance.<br/>
 * 
 */

public class MetaDomainObject<IDField, E extends DomainObject<IDField>> {

	private Class<E> MyClass = null;
	private IDField ID;
	
	public MetaDomainObject(Class<E> myclass, IDField id) {
		MyClass = myclass;
		ID = id;
	}
	
	public Class<E> getInnerClass() {
		return MyClass;
	}
	
	public IDField getID() {
		return ID;
	}

	/**
	 * This equals method takes an Object as a parameter and then delegates the equality test to the appropriate equals method.
	 */
	
	public boolean equals(Object d) {
		if(d instanceof DomainObject) return equals((DomainObject<?>) d);
		if(d instanceof MetaDomainObject<?, ?>)  {
			return ((MetaDomainObject) d).getID().equals(getID()) && ((MetaDomainObject) d).getInnerClass().equals(getInnerClass());
		}
		return false;
	}
	
	/**
	 * This is an equality test that takes a DomainObject as a parameter, and tests it against the current MetaDomainObject
	 */
	public boolean equals(DomainObject<?> d) {
		try {
			return ((getID().equals(d.getId())) && getInnerClass().isInstance(d));
		} catch (Exception e) {
			return false;
		}	
	}
	
	/**
	 * This is an equality test that takes a MetaDomainObject as a parameter, and tests it against the current MetaDomainObject
	 */
	
	public boolean equals(MetaDomainObject<?, ?> d) {
		try {
			return (
					(getID().equals(d.getID())) 
					&& 
					(getInnerClass() == d.getInnerClass()));
		} catch (Exception e) {
			return false;
		}	
	}
	
}
