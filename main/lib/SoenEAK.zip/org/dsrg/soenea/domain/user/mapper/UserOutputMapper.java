package org.dsrg.soenea.domain.user.mapper;

import java.sql.SQLException;

import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.domain.mapper.LostUpdateException;
import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.service.tdg.UserTDG;


/**
 * This is a standard persistence mapper. It cascades all inserts, updates, and deletes to the roles associated with the given user.<br/>
 * Aside from that, it's standard.
 *
 */

public class UserOutputMapper implements GenericOutputMapper<Long, User>{

	/**
	 * Using this method to delete a user also deletes all of the users roles, maintaining consistency in your data store. 
	 */
	
	public void delete(User d) throws MapperException {
		try {
			int count = UserTDG.delete(d.getId(), d.getVersion());
			if(count == 0) throw new LostUpdateException("When trying to delete, User with version: " + d.getVersion() + " and id: " + d.getId() + " was not foubd.");
			deleteRoles(d);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void deleteRoles(User d) throws SQLException {
		UserTDG.deleteUserRole(d.getId());
	}

	public void insert(User d) throws MapperException {
		try {
			UserTDG.insert(d.getId(), d.getVersion(), d.getUsername(), d.getPassword());
			insertRoles(d);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void insertRoles(User d) throws SQLException, MapperException {
		for(IRole r: d.getRoles()) {
			int result = UserTDG.insertUserRole(d.getId(), r.getId());
			if(result == 0) throw new MapperException("Unable to insert User Role: " + d.getUsername() + 
					"("+d.getId()+") " + r.getName() + "(" + r.getId() + ")");
		}
	}

	public void update(User d) throws MapperException {
		try {
			int count = 0;
			if(d.hasChangedPassword()) {
				count = UserTDG.update(d.getId(), d.getVersion(), d.getUsername(), d.getPassword());
			} else {
				count = UserTDG.update(d.getId(), d.getVersion(), d.getUsername());
			}
			if(count == 0) throw new LostUpdateException("When trying to update, User with version: " + d.getVersion() + " and id: " + d.getId() + " was not foubd.");
			d.getRoles().size(); // We do this to make sure the proxies are loaded.
			deleteRoles(d);
			insertRoles(d);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
