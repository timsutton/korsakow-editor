package org.dsrg.soenea.domain.user;

import java.sql.SQLException;
import java.util.List;

import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.service.tdg.UserTDG;
import org.dsrg.soenea.uow.UoW;

public class UserFactory {

	public static  User createNew(String username, String password, List<IRole> roles) throws SQLException{
		return createNew(UserTDG.getMaxId(), 1, username, password, roles);
	}
	
	public static  User createNew(long id, long version, String username, String password, List<IRole> roles) throws SQLException{
		User u = new User(id, 1, username, roles);
		u.setPassword(password);
		UoW.getCurrent().registerNew(u);
		return u;
	}
	
	public static User createClean(long id, long version, String username, List<IRole> roles) {
		User u = new User(id, version, username, roles);
		UoW.getCurrent().registerClean(u);
		return u;
	}
}
