package org.dsrg.soenea.domain.user;

import java.sql.SQLException;
import java.util.List;

import org.dsrg.soenea.domain.DomainObjectCreationException;
import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.proxy.DomainObjectProxy;
import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.domain.user.mapper.UserInputMapper;
/**
 * This proxy extends DomainObjectProxy. In that class, you will find an ID attribute,<br/>
 * and an InnerObject attribute, which is of type DomainObject. All getters and setters in this class refer to that object.<br/>
 *
 */
public class UserProxy extends DomainObjectProxy<Long, User> implements IUser {

	public UserProxy(Long id) {
		super(id);
	}

	@Override
	protected User getFromMapper(Long id) throws SQLException,
			DomainObjectCreationException {
		try {
			return UserInputMapper.find(getId());
		} catch (MapperException e) {
			throw new DomainObjectCreationException(e);
		}
	}

	public String getPassword() {
		return getInnerObject().getPassword();
	}

	public List<IRole> getRoles() {
		return getInnerObject().getRoles();
	}

	public String getUsername() {
		return getInnerObject().getUsername();
	}

	public void setRoles(List<IRole> roles) {
		getInnerObject().setRoles(roles);
	}

	public void setPassword(String password) {
		getInnerObject().setPassword(password);
	}

	public void setUsername(String username) {
		getInnerObject().setUsername(username);
	}

	public boolean hasRole(Class<? extends IRole> role) {
		return getInnerObject().hasRole(role);
	}

	public boolean hasChangedPassword() {
		return getInnerObject().hasChangedPassword();
	}
	
	public boolean equals(Object obj) {
		if (obj instanceof UserProxy) return getId().equals(((UserProxy)obj).getId());
		if (obj instanceof User) return getId().equals(((User)obj).getId());
		return false;		
	}
	
	public int hashCode() {
		return (IUser.class.getCanonicalName() + getId()).hashCode();
	}	
}
