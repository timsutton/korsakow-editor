package org.dsrg.soenea.domain.user;

import java.util.List;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.role.IRole;

/**
 * A slightly less simple POJO for representing users.
 * We now Consider Roles.
 * 
 * @author Stuart Thiel
 *
 */
public class User extends DomainObject<Long> implements IUser{
	private String username;
	private String password = "";
	private List<IRole> roles;
	private boolean hasChangedPassword = false;
	
	/**
	 * This is the constructor that should be called when creating a new User.
	 */
	
	public User(long id, String username, List<IRole> roles) {
		this(id, 0, username, roles);
	}

	/**
	 * This is the constructor that is called by the UserInputMapper. It should only be called when creating users from the data store.
	 */
	
	public User(long id, long version, String username, List<IRole> roles) {
		super(id, version);
		this.username = username;
		this.roles = roles;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
		this.hasChangedPassword = true;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String toString() {
		return getUsername();
	}

	public List<IRole> getRoles() {
		return roles;
	}

	public void setRoles(List<IRole> roles) {
		this.roles = roles;
		
	}

	public boolean hasRole(Class<? extends IRole> role) {
		for(IRole r: roles) {
			if(role.isInstance(r)) return true;
		}
		return false;
	}

	public boolean hasChangedPassword() {
		return hasChangedPassword;
	}

	public int hashCode() {
		return (IUser.class.getCanonicalName() + getId()).hashCode();
	}	
}
