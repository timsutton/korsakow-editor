package org.dsrg.soenea.domain.user.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.mapper.DomainObjectNotFoundException;
import org.dsrg.soenea.domain.mapper.IdentityMap;
import org.dsrg.soenea.domain.role.RoleListProxy;
import org.dsrg.soenea.domain.user.IUser;
import org.dsrg.soenea.domain.user.User;
import org.dsrg.soenea.domain.user.UserFactory;
import org.dsrg.soenea.domain.user.UserProxy;
import org.dsrg.soenea.service.tdg.finder.UserFinder;
import org.dsrg.soenea.uow.ObjectRemovedException;

/**
 * This class retrieves information from the data store, and instantiates concrete users.
 * @author Stuart Thiel
 *
 */

public abstract class UserInputMapper {

	/**
	 * This method will return all Users in the data store.
	 */
	
	public static List<IUser> findAll() throws SQLException, MapperException {
		ArrayList<IUser> l = new ArrayList<IUser>();
		
		ResultSet rs = UserFinder.findAll();
		while(rs.next()) {
			try {
				l.add(IdentityMap.get(rs.getLong("id"), User.class));
				continue;
			} catch (DomainObjectNotFoundException e) {
			} catch (ObjectRemovedException e) {}
			l.add(new UserProxy(rs.getLong("id")));
		}
		
		return l;
	}

	public static User find(long id)  throws SQLException, MapperException {
		try {
			return IdentityMap.get(id, User.class);
		} catch (DomainObjectNotFoundException e) {
		} catch (ObjectRemovedException e) {

		}
		ResultSet rs = UserFinder.find(id);
		if(!rs.next()) throw new MapperException("User with id " + id + " does not exist.");
		return getUser(rs);
	}
	
	/**
	 * This map function matches on both username AND password. It is commonly used to verify authentication.
	 */

	public static User find(String username, String password) throws SQLException, MapperException {
		ResultSet rs = UserFinder.find(username, password);
		if(!rs.next()) throw new MapperException("User with that Username/Password doesn't exist!");
		
		try {
			return IdentityMap.get(rs.getLong("id"), User.class);
		} catch (DomainObjectNotFoundException e) {
		} catch (ObjectRemovedException e) {

		}
		return getUser(rs);
		
	}
	
	public static User find(String username) throws SQLException, MapperException {
		ResultSet rs = UserFinder.find(username);
		if(!rs.next()) throw new MapperException("User with that Username doesn't exist!");
		
		try {
			return IdentityMap.get(rs.getLong("id"), User.class);
		} catch (DomainObjectNotFoundException e) {
		} catch (ObjectRemovedException e) {

		}
		
		return getUser(rs);
		
	}	

	private static User getUser(ResultSet rs) throws SQLException {
		return UserFactory.createClean(rs.getLong("id"), 
				rs.getLong("version"), 
				rs.getString("username").trim(), 
				new RoleListProxy(new UserProxy(rs.getLong("id"))));
	}
	
}
