package org.dsrg.soenea.domain.user;

import java.util.List;

import org.dsrg.soenea.domain.interf.IDomainObject;
import org.dsrg.soenea.domain.role.IRole;

/**
 * This allows the abstraction of the User class, which enables us to use proxies, should they be necessary.
 *
 */

public interface IUser extends IDomainObject<Long>{
	public String getUsername();
	public String getPassword();
	public void setUsername(String username);
	public void setPassword(String password);
	public List<IRole> getRoles();
	public void setRoles(List<IRole> roles);
	public boolean hasRole(Class<? extends IRole> role);
	public boolean hasChangedPassword();
}
