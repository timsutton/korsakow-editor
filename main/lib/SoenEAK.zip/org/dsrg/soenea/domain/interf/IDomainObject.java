package org.dsrg.soenea.domain.interf;

/**
 * This is an interface for Domain Objects, which allows us abstract various inherited types of domain objects.<br/> 
 * It also allows us to use proxies and lazy load Domain Objects. A domain object proxy is essentially a domain object<br/>
 * which contains only enough information to find the real domain object in the database. This way the object is not <br/>
 * loaded at runtime until it is requested, at which point the proxy finds the REAL domain object and delegates to it.<br/><br/>
 * 
 * For example, if we had a Course which had a list of students, to save time and memory we would load student proxies instead.<br/>
 * When we would want to find the name of student with id=23, we would go through the list until we found the proxy with id=23 <br/>
 * then call the getName() method of the proxy. This would look like : <br/> <br/>
 * 
 *  	public String getName() 												<br/>
 *  	{ 																		<br/>
 *  		if (internalStudent == null)  										<br/>
 *  			internalStudent = StudentMapper.find(internalId);				<br/>
 *  		return internalStudent.getName();									<br/>
 *  	}																		<br/>
 *      
 * @author user
 *
 */
public interface IDomainObject<IDField> {

	public IDField getId();

	public long getVersion();
	
	public void setVersion(long new_version);
	
	
}
