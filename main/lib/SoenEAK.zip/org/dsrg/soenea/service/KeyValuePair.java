package org.dsrg.soenea.service;

import java.util.Map;

public class KeyValuePair<KeyType, ValueType> implements Map.Entry<KeyType, ValueType> {
	private KeyType myKey;
	private ValueType myValue;
	
	public KeyValuePair(KeyType key, ValueType value) {
		// TODO Auto-generated constructor stub
		myKey = key;
		myValue = value;
	}

	@Override
	public String toString() {
		return myValue.toString();
	}
	
	@Override
	public boolean equals(Object key) {
		return myKey.equals(key);
	}

	public KeyType getKey() {
		return myKey;
	}

	public ValueType getValue() {
		return myValue;
	}

	public ValueType setValue(ValueType value) {
		ValueType old_value = myValue;
		myValue = value;
		return old_value;
	}
}
