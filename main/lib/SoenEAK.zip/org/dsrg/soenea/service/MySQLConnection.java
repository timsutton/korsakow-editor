package org.dsrg.soenea.service;

import java.sql.Connection;
import java.sql.SQLException;

public class MySQLConnection extends SoenEAConnection {

	public MySQLConnection(Connection con){
		super(con);
	}
	
	@Override
	public void lockTable(String tableName) throws SQLException {
		createStatement().execute("LOCK TABLE " + tableName + " WRITE");
	}

	@Override
	public void unlockTable(String tableName) throws SQLException {
		createStatement().execute("UNLOCK TABLES");	
	}
	
	

}
