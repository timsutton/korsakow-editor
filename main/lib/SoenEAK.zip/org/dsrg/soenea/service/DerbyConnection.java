package org.dsrg.soenea.service;

import java.sql.Connection;
import java.sql.SQLException;

public class DerbyConnection extends SoenEAConnection {

	public DerbyConnection(Connection con){
		super(con);
	}
	@Override
	public void lockTable(String tableName) throws SQLException {
		innerConnection.setAutoCommit(false);
		createStatement().execute("LOCK TABLE " + tableName + " IN EXCLUSIVE MODE");
	}

	@Override
	public void unlockTable(String tableName) throws SQLException {
		innerConnection.commit();
	}

}
