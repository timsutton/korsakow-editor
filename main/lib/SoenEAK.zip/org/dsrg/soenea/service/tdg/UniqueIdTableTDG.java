package org.dsrg.soenea.service.tdg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.dsrg.soenea.service.logging.SQLLogger;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
/**
 * This is a TDG that should be used for any database that can have multiple applications accessing the same table.
 * It currently only works for databases that supports my SQL, and the UNLOCK TABLES command. In order to adapt it to other databases,
 * the LOCK_TABLE and UNLOCK_TABLE strings need to be changed. Also, this TDG will always connect to the database using a connection with
 * key "lock".
 * @author user
 *
 */
public class UniqueIdTableTDG {
	
	public static final String CONNECTIONTYPEKEY = "lock";
	public static final String TABLE_NAME = DbRegistry.getTablePrefix(CONNECTIONTYPEKEY)+"UniqueIdTable";
	
	private static final String CREATE_TABLE =
	 "CREATE TABLE " + TABLE_NAME + " ( " +
	 "tableName VARCHAR(128), " +
	 "fieldName VARCHAR(128), " +
	 "currentMaxId INTEGER, " +
	 "PRIMARY KEY (tableName, fieldName) " +
	 ")";
	
	private static final String DROP_TABLE = 
		"DROP TABLE " + TABLE_NAME;
	
	private static final String INSERT_SQL =
		"INSERT INTO " + TABLE_NAME + " VALUES (?, ?, ?)";
	
	private static final String UPDATE_SQL = 
		"UPDATE " + TABLE_NAME + " SET currentMaxId=? " +
		"WHERE tableName = ? AND fieldName = ?";
	
	private static final String DELETE_SQL = 
		"DELETE FROM " + TABLE_NAME + " WHERE tableName = ? AND fieldName = ?";
	
	public static void createTable() throws SQLException{
		SQLLogger.processUpdate(DbRegistry.getDbConnection(CONNECTIONTYPEKEY).createStatement(), CREATE_TABLE);
	}

	public static void dropTable() throws SQLException {
		SQLLogger.processUpdate(DbRegistry.getDbConnection(CONNECTIONTYPEKEY).createStatement(), DROP_TABLE);
	}
	
	public static void lockTable() throws SQLException {
		DbRegistry.getDbConnection(CONNECTIONTYPEKEY).lockTable(TABLE_NAME);
	}
	
	public static void unlockTable() throws SQLException {
		DbRegistry.getDbConnection(CONNECTIONTYPEKEY).unlockTable(TABLE_NAME);
	}
	
	public static int insert(String table, String field, long currentMaxId) throws SQLException {
		Connection con = DbRegistry.getDbConnection(CONNECTIONTYPEKEY);
		PreparedStatement ps = con.prepareStatement(INSERT_SQL);
		ps.setString(1, table);
		ps.setString(2, field);
		ps.setLong(3, currentMaxId);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int update(String table, String field, long currentMaxId) throws SQLException {
		Connection con = DbRegistry.getDbConnection(CONNECTIONTYPEKEY);
		PreparedStatement ps = con.prepareStatement(UPDATE_SQL);
		ps.setLong(1, currentMaxId);
		ps.setString(2, table);
		ps.setString(3, field);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int delete(String table, String field) throws SQLException {
		Connection con = DbRegistry.getDbConnection(CONNECTIONTYPEKEY);
		PreparedStatement ps = con.prepareStatement(DELETE_SQL);
		ps.setString(1, table);
		ps.setString(2, field);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
}
