package org.dsrg.soenea.service.tdg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.dsrg.soenea.service.UniqueIdFactory;
import org.dsrg.soenea.service.logging.SQLLogger;
import org.dsrg.soenea.service.threadLocal.DbRegistry;

public class UserTDG {
	public static String BASE = "User";
	public static String BASE_ROLE = "UserRole";
	public static String USER_TABLE = DbRegistry.getTablePrefix()+BASE;
	public static String USER_ROLE_TABLE = DbRegistry.getTablePrefix()+BASE_ROLE;
	
	public static String CREATE_USER_ROLE_SQL = 
		 "CREATE TABLE IF NOT EXISTS " + USER_ROLE_TABLE + " ( " +
		 "user_id INTEGER, " +
		 "role_id INTEGER, " +
		 "PRIMARY KEY (user_id, role_id) " +
		 ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";

	public static String DROP_USER_ROLE_SQL = 
		"DROP TABLE " + USER_ROLE_TABLE + ";";

	public static String INSERT_USER_ROLE_SQL = 
		"INSERT INTO " + USER_ROLE_TABLE + " " +
		"(user_id, role_id) VALUES(?, ?);";
		
	public static String DELETE_USER_ROLE_SQL = 
		"DELETE FROM " + USER_ROLE_TABLE + " " +
		"WHERE user_id=?;";
	
	
	public static String CREATE_SQL = 
		 "CREATE TABLE IF NOT EXISTS " + USER_TABLE + " ( " +
		 "id INTEGER, " +
		 "version INTEGER, " +
		 "username VARCHAR(64) unique, " +
		 "password VARCHAR(256), " +
		 "PRIMARY KEY (id) " +
		 ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
	public static String DROP_SQL = 
		"DROP TABLE " + USER_TABLE + ";";
	
	public static String INSERT_SQL = 
		"INSERT INTO " + USER_TABLE + " " +
		"(id, version, username, password) VALUES(?, ?, ?, password(?));";
	
	public static String UPDATE_SQL = 
		"UPDATE " + USER_TABLE + " " +
		"SET version=version+1, username=?, password=password(?) " +
		"WHERE id=? AND version=?;";
	
	public static String UPDATE_WO_PASSWORD_SQL = 
		"UPDATE " + USER_TABLE + " " +
		"SET version=version+1, username=? " +
		"WHERE id=? AND version=?;";
		
	public static String DELETE_SQL = 
		"DELETE FROM " + USER_TABLE + " " +
		"WHERE id=? AND version=?;";
	
	public static void createTable() throws SQLException {
		SQLLogger.processUpdate(DbRegistry.getDbConnection().createStatement(), CREATE_SQL);
	}
	
	public static void dropTable() throws SQLException {
		SQLLogger.processUpdate(DbRegistry.getDbConnection().createStatement(), DROP_SQL);
	}
	
	public static void createUserRoleTable() throws SQLException {
		SQLLogger.processUpdate(DbRegistry.getDbConnection().createStatement(), CREATE_USER_ROLE_SQL);
	}
	
	public static void dropUserRoleTable() throws SQLException {
		SQLLogger.processUpdate(DbRegistry.getDbConnection().createStatement(), DROP_USER_ROLE_SQL);
	}

	public static int insertUserRole(long user_id, long role_id) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(INSERT_USER_ROLE_SQL);
		ps.setLong(1, user_id);
		ps.setLong(2, role_id);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int insert(long id, long version, String username, String password) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(INSERT_SQL);
		ps.setLong(1, id);
		ps.setLong(2, version);
		ps.setString(3, username);
		ps.setString(4, password);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int update(long id, long version, String username, String password) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(UPDATE_SQL);
		ps.setString(1, username);
		ps.setString(2, password);
		ps.setLong(3, id);
		ps.setLong(4, version);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int update(long id, long version, String username) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(UPDATE_WO_PASSWORD_SQL);
		ps.setString(1, username);
		ps.setLong(2, id);
		ps.setLong(3, version);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int delete(long id, long version) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(DELETE_SQL);
		ps.setLong(1, id);
		ps.setLong(2, version);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static int deleteUserRole(long user_id) throws SQLException {
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(DELETE_USER_ROLE_SQL);
		ps.setLong(1, user_id);
		int count = SQLLogger.processUpdate(ps);
		ps.close();
		return count;
	}
	
	public static long getMaxId() throws SQLException {
		return UniqueIdFactory.getMaxId(BASE, "id");
	}
	
}
