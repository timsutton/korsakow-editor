package org.dsrg.soenea.service.tdg.finder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.service.logging.SQLLogger;
import org.dsrg.soenea.service.tdg.UniqueIdTableTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;

public class UniqueIdTableFinder {
	
	public static String SELECT_BY_TABLE_FIELD_SQL = 
		"SELECT currentMaxId FROM " + UniqueIdTableTDG.TABLE_NAME + " " +
		"WHERE tableName=? AND fieldName=?";
	
	public static String SELECT_ALL_SQL = 
		"SELECT tableName, fieldName, currentMaxId FROM " + UniqueIdTableTDG.TABLE_NAME;
	
	public static ResultSet find(String table, String field) throws SQLException{
		Connection con = DbRegistry.getDbConnection(UniqueIdTableTDG.CONNECTIONTYPEKEY);
		PreparedStatement ps = con.prepareStatement(SELECT_BY_TABLE_FIELD_SQL);
		ps.setString(1, table);
		ps.setString(2, field);
		return SQLLogger.processQuery(ps);
	}
	
	public static ResultSet findAll() throws SQLException{
		Connection con = DbRegistry.getDbConnection(UniqueIdTableTDG.CONNECTIONTYPEKEY);
		PreparedStatement ps = con.prepareStatement(SELECT_ALL_SQL);
		return SQLLogger.processQuery(ps);
	}
}
