package org.dsrg.soenea.service.tdg.finder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dsrg.soenea.service.logging.SQLLogger;
import org.dsrg.soenea.service.tdg.UserTDG;
import org.dsrg.soenea.service.threadLocal.DbRegistry;

public class UserFinder {
	public static String SELECT_BY_ID_SQL = 
		"SELECT id, version, username FROM " + UserTDG.USER_TABLE + " " +
		"WHERE id=?;";
	public static String SELECT_BY_USERNAME_SQL = 
		"SELECT id, version, username FROM " + UserTDG.USER_TABLE + " " +
		"WHERE username=?;";
	public static String SELECT_BY_USERNAME_PASSWORD_SQL = 
		"SELECT id, version, username FROM " + UserTDG.USER_TABLE + " " +
		"WHERE username=? AND password=password(?);";	
	public static String SELECT_ALL_SQL = 
		"SELECT id, version, username FROM " + UserTDG.USER_TABLE + ";";
	
	public static String SELECT_ROLE_BY_USER_SQL = 
		"SELECT user_id, role_id FROM " + UserTDG.USER_ROLE_TABLE + " " +
		"WHERE user_id=?;";
	
	
	public static ResultSet find(long id) throws SQLException{
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_BY_ID_SQL);
		ps.setLong(1, id);
		return SQLLogger.processQuery(ps);
	}
	
	public static ResultSet find(String username) throws SQLException{
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_BY_USERNAME_SQL);
		ps.setString(1, username);
		return SQLLogger.processQuery(ps);
	}
	
	public static ResultSet find(String username, String password) throws SQLException{
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_BY_USERNAME_PASSWORD_SQL);
		ps.setString(1, username);
		ps.setString(2, password);
		return SQLLogger.processQuery(ps);
	}
	
	public static ResultSet findAll() throws SQLException{
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_ALL_SQL);
		return SQLLogger.processQuery(ps);
	}
	
	public static ResultSet findRoleByUser(long user_id) throws SQLException{
		Connection con = DbRegistry.getDbConnection();
		PreparedStatement ps = con.prepareStatement(SELECT_ROLE_BY_USER_SQL);
		ps.setLong(1, user_id);
		return SQLLogger.processQuery(ps);
	}
	
}
