package org.dsrg.soenea.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.MissingResourceException;

import org.dsrg.soenea.service.tdg.UniqueIdTableTDG;
import org.dsrg.soenea.service.tdg.finder.UniqueIdTableFinder;
/**
 * This class is used to provide Unique Id's for an application that will access a database that will be accessed by multiple
 * applications. In order to avoid concurrency issues, it uses locking. 
 * @author user
 *
 */
public class MultiAppUniqueIdFactory extends UniqueIdFactory {

	private static HashMap<String, Long> lowid = new HashMap<String, Long>();
	private static HashMap<String, Long> highid = new HashMap<String, Long>();
	private static int length;
	
	public MultiAppUniqueIdFactory(boolean resetHashtable) {
		if(resetHashtable) {
			lowid = new HashMap<String, Long>();
			highid = new HashMap<String, Long>();
			length = 0;
		}
	}
	
	public MultiAppUniqueIdFactory() {
		this(false);
	}
	/**
	 * Rewritten getId method as the old one had lots of big problems.
	 * 
	 * @author Brendan Asselstine
	 */
	@Override
    public synchronized long getId(String table, String field) throws SQLException {
        instantiateIdsIfNecessary(table, field);
        //if we have to grab another group of ids for this application
        if((long)lowid.get(table+"."+field) == (long)highid.get(table+"."+field))
        {
            UniqueIdTableTDG.lockTable();
            ResultSet rs = UniqueIdTableFinder.find(table, field);
            long currentMax = 0l;
            if(rs.next()){ //then claim from db
                /* we have to make sure we have the correct max id, whether
                 * the database has the max or we have a local max.  If the
                 * database is out of date we can force it to match the local
                 * copy.  I don't know if this is legal for multiple
                 * applications (although we do have a table lock)
                 */
                currentMax = rs.getLong("currentMaxId");
                if (currentMax < highid.get(table+"."+field))
                    currentMax = highid.get(table+"."+field);

                //update the database with the new max
                UniqueIdTableTDG.update(table,field,currentMax+getLength());
            } else {
                /* if there is no database entry we can just update it
                 * with the local max.
                 */
                currentMax = (long) highid.get(table+"."+field);
                UniqueIdTableTDG.insert(table,field,currentMax+getLength());
            }
            lowid.put(table+"."+field, currentMax + 1);
            highid.put(table+"."+field, currentMax + getLength());
            UniqueIdTableTDG.unlockTable();
        }
        else //just use the ids we have
        {
            lowid.put(table+"."+field, lowid.get(table+"."+field) + 1);
        }
        return lowid.get(table+"."+field);
    }

	private void instantiateIdsIfNecessary(String table, String field) {
		if(lowid.get(table+"."+field) == null){
			lowid.put(table+"."+field, (long)0);
			highid.put(table+"."+field, (long)0);
		}
	}
	
	protected int getLength(){
		if(length == 0){
			try {
				length = Integer.parseInt(Registry.getProperty("numberOfIdsToGrab"));
			} catch (MissingResourceException e) {
				length = 1;	
			} catch (NumberFormatException e) {
				length = 1;	
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(length < 1)
				throw new RuntimeException("You may not use a negative length in MyResources.Properties for numberOfIdsToGrab.");
		}
		return length;
			
	}
}
