package org.dsrg.soenea.service;

import java.sql.SQLException;
/**
 * UniqueIdFactory currently has two different implementations. SingleAppUniqueIdFactory is to be used for applications
 * where the application is the only application that will be accessing the database, 
 * whereas MultiAppUniqueIdFactory is to be used for applications where there will be a second application reading from the same
 * database tables.
 * @author user
 *
 */
public abstract class UniqueIdFactory {
	
	private static UniqueIdFactory uif = null;
	private static final String uiflock = "uiflock";
	
	/**
	 * The reason there is both a getMaxId() method and a getId() method is for backwards compatibility
	 * @param table
	 * @param field
	 * @return
	 * @throws SQLException
	 */
	public static long getMaxId(String table, String field) throws SQLException {
		
		return getInstance().getId(table, field);
	}
	
	public static void setFactory(UniqueIdFactory newFactory){
		synchronized (uiflock) {
			uif = newFactory;
		}
		
	}
	
	private static UniqueIdFactory getInstance(){
		synchronized (uiflock) {
		if(uif == null)
			setFactory(new SingleAppUniqueIdFactory());
		return uif;
		}
	}
	
	public abstract long getId(String table, String field) throws SQLException;
}
