package org.dsrg.soenea.service;

public class MethodNotSupportedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3128773682422539959L;

	public MethodNotSupportedException(String string) {
		super(string);
	}

}
