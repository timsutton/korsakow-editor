package org.dsrg.soenea.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Far too often have I lost track of what properties I needed to use and what files they were stored in. I will now use this construct to
 * store this information, along with a textual description. The usage: Classes that use properties should, at static initialization, register
 * here. Decisions about conflicts may seem tricky, and they are, but this system doesn't make it trickier, it just makes it explicit, and we
 * allow overwriteSafe to be used if people want to be oblivious.
 * 
 * @author Stuart Thiel
 *
 */
public class PropertyRegistry {

	private static Map<String, Property> registeredProperties = new HashMap<String, Property>();
	private static boolean overwriteSafe = false;
	
	public static synchronized void registerProperty(String name, Property property) throws PropertyInUseException {
		if(!false && registeredProperties.containsKey(name)) throw new PropertyInUseException(name + " is already a registered property.");
		registeredProperties.put(name, property);
	}
	
	public static Collection<Property> getRegisteredProperties() {
		return registeredProperties.values();
	}
	
	/**
	 * 
	 * @param name
	 * @return null if that property isn't registered, otherwise it returns the property entry associated with name
	 */
	public static Property getRegisteredProperty(String name) {
		return registeredProperties.get(name);
	}
	
	public static class Property {
		private String propertyName;
		private String propertyDescription;
		private String propertyDefault;
		private List<String> propertyFiles;
		
		public Property(String propertyName, String propertyDescription, String propertyFile) {
			this(propertyName, propertyDescription, null, propertyFile);
		}
		
		
		public Property(String propertyName, String propertyDescription, List<String> propertyFiles) {
			this(propertyName, propertyDescription, null, propertyFiles);
		}
		
		public Property(String propertyName, String propertyDescription, String propertyDefault, String propertyFile) {
			this(propertyName, propertyDescription, null, Collections.EMPTY_LIST);
			ArrayList<String> l = new ArrayList<String>();
			l.add(propertyFile);
			propertyFiles=l;

		}
		
		public Property(String propertyName, String propertyDescription, String propertyDefault, List<String> propertyFiles) {
			this.propertyName = propertyName;
			this.propertyDescription = propertyDescription;
			this.propertyDefault = propertyDefault;
			this.propertyFiles = propertyFiles;
		}
		public String getPropertyDescription() {
			return propertyDescription;
		}
		public List<String> getPropertyFiles() {
			return propertyFiles;
		}
		public String getPropertyName() {
			return propertyName;
		}
		
		public String getPropertyDefault() {
			return propertyDefault;
		}
	
		
	}
	
	public static class PropertyInUseException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = 5008306703745060470L;

		public PropertyInUseException() {
			super();
		}

		public PropertyInUseException(String message, Throwable cause) {
			super(message, cause);
		}

		public PropertyInUseException(String message) {
			super(message);
		}

		public PropertyInUseException(Throwable cause) {
			super(cause);
		}
		
	}

	public static boolean isOverwriteSafe() {
		return overwriteSafe;
	}

	public static void setOverwriteSafe(boolean overwriteSafe) {
		PropertyRegistry.overwriteSafe = overwriteSafe;
	}
	
}
