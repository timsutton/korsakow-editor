package org.dsrg.soenea.service.authorization;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.dsrg.soenea.domain.role.IRole;
import org.dsrg.soenea.service.PropertyRegistry;
import org.dsrg.soenea.service.Registry;
import org.dsrg.soenea.service.PropertyRegistry.PropertyInUseException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.sun.org.apache.xpath.internal.XPathAPI;

public class ApplicationAuthorizaton {
	private static String propertyFile = "Myresources.properties";
	private static String propertyName = "AccessXMLFile";
	static {
		try {
			PropertyRegistry.registerProperty(propertyName, new PropertyRegistry.Property(propertyName, 
					"This property tells us the path, relative to the servlet context, of the Access.xml file.", propertyFile));
		} catch (PropertyInUseException e) {
			e.printStackTrace();
		}
		
	}
	
	private static Document accessDocument;
	private static String basePath=".";
	
	public static void setBasePath(String basePath) {
		ApplicationAuthorizaton.basePath = basePath;
	}
	
	public static boolean hasAuthority(String command, List<IRole> roles) {
	
		for (IRole role : roles) {
			String canonicalName = role.getClass().getCanonicalName();
			String query = "role[@name=\"" + canonicalName + "\"]/command[@name=\"" + command + "\"]";
			Logger.getLogger("org.dsrg").log(Level.FINEST, "XPath Role Lookup: " + query);
			boolean hasRole;
			try {
				hasRole = XPathAPI.eval(getAccessDocument().getDocumentElement(), query).bool();
			} catch (Exception e) {
				Logger.getLogger("org.dsrg").throwing(ApplicationAuthorizaton.class.getName(), "isValidUserForCommand", e);
				hasRole = false;
			}
			if (hasRole)
				return true;
		}
		
		return false;
	}
	
	private static synchronized Document getAccessDocument() throws SAXException, IOException, Exception {
		if (accessDocument == null) {
			final String docPath = basePath+File.separatorChar+Registry.getProperty(propertyName);
			Logger.getLogger("org.dsrg").log(Level.FINEST, "Building accessDocument from: " + docPath);
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			accessDocument = builder.parse(new File(docPath));
		}
		return accessDocument;
	}

}
