package org.dsrg.soenea.service;
/** @modelguid {001A0419-17DB-48D3-A3C1-A3D7719207B5} */
public class UnknownCommandException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1408794919544428764L;

	/**
	 * Constructor UnknownCommandException.
	 * @param string
	 * @modelguid {7961286A-97A4-40A6-84DA-8E319E0A98DB}
	 */
	public UnknownCommandException(String cmdOrMsg) {
		super(cmdOrMsg);
	}

}

