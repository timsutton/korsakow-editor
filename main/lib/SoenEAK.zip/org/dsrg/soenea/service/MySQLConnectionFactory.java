/*
 * Created on Apr 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.dsrg.soenea.service;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.MissingResourceException;

import org.dsrg.soenea3.ts.ApplicationConfigRegistry;
import org.dsrg.soenea3.ts.NoSuchPropertyException;

/**
 * This sets up a mechanism by which database request parameters are set up
 * once, and then all subsequent requests to getConnection will get a 
 * database connection based on those initial setup parameters. This is
 * meant to be wrapped inside something else, but I suppose it could be used
 * independently.
 * 
 * @author Stuart Thiel
 */
public class MySQLConnectionFactory extends ConnectionFactory {
	private static String dbDriver = "org.gjt.mm.mysql.Driver";

	public MySQLConnectionFactory(String host, String dbn, String usr, String pwd) {
	    try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e1) {
			System.err.println(dbDriver + "doesn't seem to exist.");
		}
		setUserName(usr);
		setHostName(host);
		setDatabaseName(dbn);
		setPassWord(pwd);
	}

	public MySQLConnectionFactory(String host, String dbn, String usr, String pwd, int port) {
		this(host, dbn, usr, pwd);
		setPort(port);
	}
	
    private String UserName = "";
    private String HostName= "";
    private String DatabaseName = "";
    private String PassWord = "";
    private int Port = 3306;
	
	/* (non-Javadoc)
	 * @see MovieMapper.TechnicalServices.Database.ConnectionFactory#getConnection()
	 */
	public MySQLConnection getConnection() throws SQLException {
		return new MySQLConnection(DriverManager.getConnection(getDBURL(), getUserName(), PassWord));
	}

	/**
	 * This method initialized the factory with Default information
	 * @throws SQLException 
	 */
	public void defaultInitialization() throws SQLException  {
		defaultInitialization("");
	}
	
	/**
	 * This method initialized the factory with Default information
	 */
	public void defaultInitialization(String connectionType) throws SQLException {
		Exception ex = null;
		try {
			setHostName(ApplicationConfigRegistry.getProperty(connectionType+"mySqlHostName"));
			setDatabaseName(ApplicationConfigRegistry.getProperty(connectionType+"mySqlDatabase"));
			setUserName(ApplicationConfigRegistry.getProperty(connectionType+"mySqlUserName"));
			setPassWord(ApplicationConfigRegistry.getProperty(connectionType+"mySqlPassword"));
			return;
		} catch (MissingResourceException e) {
			ex = e;
		} catch (NoSuchPropertyException e) {
			ex = e;
		}
		// The method signature forces us to throw an SQLException.
		throw new SQLException("defaultInitialization("+connectionType+") failure" + ex.getMessage());
	}

	/**
	 * @return Returns the databaseName.
	 */
	public String getDatabaseName() {
		return DatabaseName;
	}
	/**
	 * @param databaseName The databaseName to set.
	 */
	public void setDatabaseName(String databaseName) {
		DatabaseName = databaseName;
	}
	/**
	 * @return Returns the dBURL.
	 */
	public String getDBURL() {
		return "jdbc:mysql://" + getHostName() + "/" + getDatabaseName();
	}
	/**
	 * @return Returns the hostName.
	 */
	public String getHostName() {
		return HostName;
	}
	/**
	 * @param hostName The hostName to set.
	 */
	public void setHostName(String hostName) {
		HostName = hostName;
	}
	/**
	 * @return Returns the userName.
	 */
	public String getUserName() {
		return UserName;
	}
	/**
	 * @param userName The userName to set.
	 */
	public void setUserName(String userName) {
		UserName = userName;
	}
	/**
	 * @param passWord The passWord to set.
	 */
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	/**
	 * @return Returns the port.
	 */
	public int getPort() {
		return Port;
	}
	/**
	 * @param port The port to set.
	 */
	public void setPort(int port) {
		Port = port;
	}
}
