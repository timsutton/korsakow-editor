package org.dsrg.soenea.service.logging;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLLogger {
	private static long logThreshold;

	public static long getLegThreshold() {
		return logThreshold;
	}

	public static void setLegThreshold(long logThreshold) {
		SQLLogger.logThreshold = logThreshold;
	}
	
	public static int processUpdate(PreparedStatement ps) throws SQLException {
		String sql = ps.toString();
		long now = System.currentTimeMillis();
		int count = 0;
		try {
			count = ps.executeUpdate();
			if(System.currentTimeMillis()-now > logThreshold) {
				Logging.logSQL("Update took " + (System.currentTimeMillis()-now) + "ms:");
				Logging.logSQL(sql);
			}
			return count;
		} catch (SQLException e) {
			Logging.logSQL(sql);
			throw e;
		}
	}
	
	public static int processUpdate(Statement s, String sql) throws SQLException {
		if(s instanceof PreparedStatement) {
			throw new SQLException("We can't take PreparedStatements like this!");
		}		
		long now = System.currentTimeMillis();
		int count = 0;
		try {
			count = s.executeUpdate(sql);
			if(System.currentTimeMillis()-now > logThreshold) {
				Logging.logSQL("Update took " + (System.currentTimeMillis()-now) + "ms:");
				Logging.logSQL(sql);
			}
			return count;
		} catch (SQLException e) {
			Logging.logSQL(sql);
			throw e;
		}
	}
	
	public static ResultSet processQuery(PreparedStatement ps) throws SQLException {
		String sql = ps.toString();
		long now = System.currentTimeMillis();
		ResultSet rs = null;
		try {
			rs = ps.executeQuery();
			if(System.currentTimeMillis()-now > logThreshold) {
				Logging.logSQL("Query took " + (System.currentTimeMillis()-now) + "ms:");
				Logging.logSQL(sql);
			}
			return rs;
		} catch (SQLException e) {
			Logging.logSQL(sql);
			throw e;
		}
	}
	
	public static ResultSet processQuery(Statement s, String sql) throws SQLException {
		if(s instanceof PreparedStatement) {
			throw new SQLException("We can't take PreparedStatements like this!");
		}
		long now = System.currentTimeMillis();
		ResultSet rs = null;
		try {
			rs = s.executeQuery(sql);
			if(System.currentTimeMillis()-now > logThreshold) {
				Logging.logSQL("Query took " + (System.currentTimeMillis()-now) + "ms:");
				Logging.logSQL(sql);
			}
			return rs;
		} catch (SQLException e) {
			Logging.logSQL(sql);
			throw e;
		}
	}
}
