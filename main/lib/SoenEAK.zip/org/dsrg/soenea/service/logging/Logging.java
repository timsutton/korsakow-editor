package org.dsrg.soenea.service.logging;

import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.dsrg.soenea.service.threadLocal.ThreadLocalTracker;


/**
 * Ripped from the BioInformatics project pretty much verbatim
 * 
 * @author Brendan Asselstine
 *
 */
public class Logging {
	
	public static final Level SQL_LOG_LEVEL = Level.FINEST;
	public static final Level DEBUG_LOG_LEVEL = Level.FINER;
	public static final Level STD_LOG_LEVEL = Level.FINE;
	public static final Level TEST_LOG_LEVEL = Level.FINE;
	public static final Level ERROR_LOG_LEVEL = Level.SEVERE;

	private static String loggerString = "";
	
	public static void setLoggerString(String newLoggerString) {
		loggerString = newLoggerString;
	}
	
	private static class ThreadLocalStackTrace extends ThreadLocal<Stack<String>> {
		public ThreadLocalStackTrace() {
			super();
			ThreadLocalTracker.registerThreadLocal(this);
		}
		@Override
		public Stack<String> initialValue() {
		   return new Stack<String>();
		}
	}
	
	private static ThreadLocalStackTrace stackTrace = new ThreadLocalStackTrace();
	
	public static Stack<String> getStackTrace()
	{
		Stack<String> stack = stackTrace.get();
		if (stack == null)
		{
			stackTrace.set(new Stack<String>());
			stack = stackTrace.get();
		}
		return stack;
	}
	
	public static void pushStackTrace(String s)	{
		
		Stack<String> stack = getStackTrace();
		stack.push(s);
	}
	
	public static void popStackTrace() {
		Stack<String> stack = getStackTrace();
		stack.pop();
	}
	
	public static String getStackTraceString() {
		String result = null;
		Stack<String> stack = getStackTrace();
		for (String s : stack)
		{
			if (result != null)
				result += ": ";
			else
				result = "";
			result += s;
		}
		if (result == null)
			result = "";
		return result;
	}

	public static void log(String logstring)
	{
		log(STD_LOG_LEVEL,logstring);
	}
	
	public static void logSQL(String logstring)
	{
		log(SQL_LOG_LEVEL,logstring);
	}
	
	public static void logDebug(String logstring)
	{
		log(DEBUG_LOG_LEVEL,logstring);
	}
	
	public static void logTest(String string) {
		log(TEST_LOG_LEVEL,string);
	}
	
	public static void logError(String string) {
		log(ERROR_LOG_LEVEL,string);
	}
	
	public static void log(Level loglevel, String logstring) {
		Logger.getLogger(loggerString).log(loglevel, getStackTraceString() + ": " + logstring);
	}

}
