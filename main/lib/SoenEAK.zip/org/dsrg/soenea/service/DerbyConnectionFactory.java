package org.dsrg.soenea.service;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * This sets up a mechanism by which database request parameters are set up
 * once, and then all subsequent requests to getConnection will get a 
 * database connection based on those initial setup parameters. This is
 * meant to be wrapped inside something else, but I suppose it could be used
 * independently.
 * 
 * This is the version for using an embedded Derby DB.
 * 
 * @author Stuart Thiel
 */
public class DerbyConnectionFactory extends ConnectionFactory {
	/**
	 * 
	 */
	public DerbyConnectionFactory(String dbn) {
    	new org.apache.derby.jdbc.EmbeddedDriver();
		DatabaseName=dbn;
	}
    private String DatabaseName = "";
	
	/* (non-Javadoc)
	 * @see MovieMapper.TechnicalServices.Database.ConnectionFactory#getConnection()
	 */
	public DerbyConnection getConnection() throws SQLException {
		return new DerbyConnection(DriverManager.getConnection("jdbc:derby:" + DatabaseName + ";create=true"));
	}

	public void defaultInitialization() throws SQLException {
				
	}
}
