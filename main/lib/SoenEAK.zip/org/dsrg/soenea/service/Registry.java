package org.dsrg.soenea.service;

import java.util.*;

/** @modelguid {D803E399-8B91-422C-80C1-E79E586F1511} */
public class Registry {
    
    /** Fowler's Registry Pattern. */
    
    /** @modelguid {0C2CBA0E-905D-419F-8E2F-326E789E8CDB} */
    private static Registry soleInstance;
    
    /** @modelguid {A64F56BC-9E03-49DC-BC95-9782F2810FAA} */
    private /*@non_null@*/ ResourceBundle myRes;
    
	/** @modelguid {5F2EB3C6-9A34-48FD-A404-C9F46FCD7B7C} */
	private static final String fileName = "MyResources";

    
    /** @modelguid {09BAC661-8B22-4744-8C4B-ACFCBA23B8CA} */
    private static /*@non_null@*/ Registry getUniqueInstance() throws Exception {
    	if(soleInstance == null)
    		soleInstance = new Registry();
        return soleInstance;
    }

    /** @modelguid {3E35E429-D823-43E8-8D7A-A8A50A3FA01B} */
    public static String getProperty(/*@non_null@*/ String key) throws Exception {
        return getUniqueInstance()._getProperty(key);
    }
    
	//@ private normal_behavior
	//@   ensures myRes != null;
	/** @modelguid {5C29A9F1-D565-4931-95B0-2D55345C35DD} */
	protected Registry() throws Exception {
		try {
			myRes = ResourceBundle.getBundle(fileName); //@nowarn
		} catch(Exception e) {
			String msg = "Registry: unable to open resource file '" + fileName + "'";
			throw new Exception(msg, e);
		}
	}
    
	/** @modelguid {B9CE0353-CC66-46FA-AD5D-DA7D42F3EDB5} */
    private /*@non_null@*/ String _getProperty(/*@non_null@*/ String key) throws Exception {
        return myRes.getString(key); // might throw MissingResourceException
    }

} // end class
