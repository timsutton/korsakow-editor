package org.dsrg.soenea.service;

public class LoggingUtility {
	public static final String LOG_STRING = "org.dsrg.soenea.soenea";
}
