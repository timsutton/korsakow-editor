package org.dsrg.soenea.service.threadLocal;

import javax.servlet.http.HttpSession;

import org.dsrg.soenea.domain.user.GuestUser;
import org.dsrg.soenea.domain.user.IUser;

public abstract class SessionThreadLocalRegistry{
	public static final String CurrentUserString = "CurrentUser";
	
	private static ThreadLocal<Object> Registry = new ThreadLocal<Object>();
	static {
		ThreadLocalTracker.registerThreadLocal(Registry);
	}
	public static void setSession(HttpSession session) {
		Registry.set(session);
	}
	
	public static IUser getCurrentUser() {
		IUser u = (IUser)((HttpSession)Registry.get()).getAttribute(CurrentUserString);
		if(u==null) {
			u = new GuestUser();
			setCurrentUser(u);
		}
		return u;
	}

	public static void setCurrentUser(IUser u) {
		((HttpSession)Registry.get()).setAttribute(CurrentUserString, u);
	}
}
