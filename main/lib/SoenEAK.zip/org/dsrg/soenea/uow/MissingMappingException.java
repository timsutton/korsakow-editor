package org.dsrg.soenea.uow;

public class MissingMappingException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 85328877359493655L;

	public MissingMappingException() {
	}

	public MissingMappingException(String message) {
		super(message);
	}

	public MissingMappingException(Throwable cause) {
		super(cause);
	}

	public MissingMappingException(String message, Throwable cause) {
		super(message, cause);
	}

}
