package org.dsrg.soenea.uow;

import org.dsrg.soenea.domain.DomainObject;

public class ObjectRemovedException extends Exception {

	DomainObject<?> removedObject;

	public ObjectRemovedException(String message, Throwable cause, DomainObject<?> removedObject) {
		super(message, cause);
		this.removedObject = removedObject;
	}

	public ObjectRemovedException(String message, DomainObject<?> removedObject) {
		super(message);
		this.removedObject = removedObject;
	}

	public ObjectRemovedException(Throwable cause, DomainObject<?> removedObject) {
		super(cause);
		this.removedObject = removedObject;
	}

	public ObjectRemovedException(DomainObject<?> removedObject) {
		this.removedObject = removedObject;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1066781564716736948L;

	public DomainObject<?> getRemovedObject() {
		return removedObject;
	}

}
