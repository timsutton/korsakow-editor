package org.dsrg.soenea.uow;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.MapperException;
import org.dsrg.soenea.domain.MetaDomainObject;
import org.dsrg.soenea.domain.MetaMapper;
import org.dsrg.soenea.domain.interf.IDomainObject;
import org.dsrg.soenea.domain.proxy.DomainObjectProxy;
import org.dsrg.soenea.environment.CreationException;
import org.dsrg.soenea.environment.KeyNotFoundException;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.service.threadLocal.ThreadLocalTracker;

public class UoW {
	protected Set<DomainObject<?>> newObjects = new HashSet<DomainObject<?>>();
	protected Set<DomainObject<?>> dirtyObjects = new HashSet<DomainObject<?>>();
	protected Set<DomainObject<?>> removedObjects = new HashSet<DomainObject<?>>();
	protected Set<DomainObject<?>> cleanObjects = new HashSet<DomainObject<?>>();
	
	private static ThreadLocal<UoW> current = new ThreadLocal<UoW>();
	
	static {
		ThreadLocalTracker.registerThreadLocal(current);
	}
	
	private static MapperFactory myFactory;
	/**
	 * Questionable Synchronization...
	 * @param f
	 */
	public static <ResourceType extends Object> void initMapperFactory(MapperFactory f) {
		MyMapper = new MetaMapper<ResourceType>();
		MyMapper.init(f);
		myFactory = f;
	}
	
	
	public static <IDField, DO extends DomainObject<IDField>> boolean hasMappingForClass(Class<DO> key) {
		return myFactory.contains(key);
	}
	
	protected static MetaMapper MyMapper;
	
	public <IDField> boolean hasDomainObject(DomainObject<IDField> d) throws ObjectRemovedException {
		return hasObject(d);
	}
	
	/**
	 * This checks if the UoW is storing a Domain Object that corresponds to the passed
	 * MetaDomainObject representation passed.
	 * 
	 * @param d
	 * @return
	 * @throws ObjectRemovedException
	 */
	public boolean hasDomainObjectRepresentedByMeta(MetaDomainObject<?, ?> d) throws ObjectRemovedException {
		return hasObject(d);
	}
	
	private boolean hasObject(Object d) throws ObjectRemovedException {
		if(contains(d, removedObjects)) {
			DomainObject<?> removedObject = null;
			for(DomainObject<?> myDO:removedObjects)
				if(myDO.equals(d))
					removedObject = myDO;
			throw new ObjectRemovedException(removedObject);
		}
		return contains(d, cleanObjects) || contains(d, newObjects) || contains(d, dirtyObjects);
	}
	
	public <IDField, DO extends DomainObject<IDField>> DO getObject(MetaDomainObject<IDField, DO> md) {
		for(DomainObject<?> myDO:newObjects)
			if(myDO.equals(md))
				return (DO)myDO;
		for(DomainObject<?> myDO:dirtyObjects)
			if(myDO.equals(md))
				return (DO)myDO;
		for(DomainObject<?> myDO:cleanObjects)
			if(myDO.equals(md))
				return (DO)myDO;
		return null;
	}
		
	public <IDField> void registerNew(IDomainObject<IDField> d) throws MissingMappingException{
		checkIfClassIsRegistered((IDomainObject<?>)d);
		DomainObject<IDField> actualDO = getInnerDomainObject(d);
		dirtyObjects.remove(actualDO);
		cleanObjects.remove(actualDO);
		removedObjects.remove(actualDO);
		newObjects.add(actualDO);
	}

	public <IDField> void registerDirty(IDomainObject<IDField> d) throws MissingMappingException{
		checkIfClassIsRegistered((IDomainObject<?>)d);
		DomainObject<IDField> actualDO = getInnerDomainObject(d);
		
		if(!contains(actualDO, dirtyObjects) && !contains(actualDO, newObjects)) {
			cleanObjects.remove(actualDO);
			removedObjects.remove(actualDO);
			dirtyObjects.add(actualDO);
		}
	}
	
	public <IDField> void registerRemoved(IDomainObject<IDField> d) throws MissingMappingException{
		checkIfClassIsRegistered((IDomainObject<?>)d);
		
		DomainObject<IDField> actualDO = getInnerDomainObject(d);
		
		if(newObjects.remove(actualDO)) return;
		cleanObjects.remove(actualDO);
		dirtyObjects.remove(actualDO);
		removedObjects.add(actualDO);
	}
	
	public <IDField> void registerClean(IDomainObject<IDField> d) throws MissingMappingException{
		checkIfClassIsRegistered((IDomainObject<?>)d);
		
		DomainObject<IDField> actualDO = getInnerDomainObject(d);
		
		newObjects.remove(actualDO);
		dirtyObjects.remove(actualDO);
		removedObjects.remove(actualDO);
		cleanObjects.add(actualDO);
	}
	
	
	public void commit() throws SQLException, KeyNotFoundException, CreationException, MapperException{
		try {
			DbRegistry.getDbConnection().setAutoCommit(false);
			insertNew();
			updateDirty();
			deleteRemoved();
			DbRegistry.getDbConnection().commit();
		} catch(MapperException e) {
			DbRegistry.getDbConnection().rollback();
			throw e;
		}
	}
	
	protected void insertNew() throws SQLException, KeyNotFoundException, CreationException, MapperException {
		for (DomainObject<?> d: newObjects) {
			MyMapper.insert(d);
		}
	}
	
	protected void updateDirty() throws SQLException, KeyNotFoundException, CreationException, MapperException {
		for (DomainObject<?> d: dirtyObjects) {
			MyMapper.update(d);
		}
	}
	
	protected void deleteRemoved() throws SQLException, KeyNotFoundException, CreationException, MapperException {
		for (DomainObject<?> d: removedObjects) {
			MyMapper.delete(d);
		}
	}

	public static void newCurrent() {
		setCurrent(new UoW());
	}
	public static void setCurrent(UoW uow) {
		current.set(uow);
	}
	public static UoW getCurrent() {
		return current.get();
	}
	
	public static boolean isUsingUoW() {
		return current.get() != null;
	}
	
	private <IDField> boolean contains(Object obj, Set<DomainObject<? extends IDField>> theSet)
	{
		for (DomainObject<? extends IDField> domainObject : theSet) 
		{
			if (domainObject.equals(obj)) 
			{
				return true;
			}
		}
		return false;
	}	
	
	private <IDField> DomainObject<IDField> getInnerDomainObject(IDomainObject<IDField> d) {
		try {
			d.getClass().asSubclass(DomainObjectProxy.class);
			return ((DomainObjectProxy<IDField, ?>) d).getInnerObject();
		} catch (ClassCastException e) {
			return (DomainObject<IDField>)d;
		}
	}
	
	@SuppressWarnings("unchecked")
	private void checkIfClassIsRegistered(IDomainObject d) throws MissingMappingException{
		if(d instanceof DomainObjectProxy) _checkIfClassIsRegistered((DomainObjectProxy)d);
		else _checkIfClassIsRegistered((DomainObject)d);
	}
	
	@SuppressWarnings("unchecked")
	private void _checkIfClassIsRegistered(DomainObjectProxy d) throws MissingMappingException{
		_checkIfClassIsRegistered(d.getInnerObject());		
	}

	@SuppressWarnings("unchecked")
	private void _checkIfClassIsRegistered(DomainObject d) throws MissingMappingException{
		if(!hasMappingForClass(d.getClass())) throw new MissingMappingException("Class " + d.getClass().getCanonicalName() + " has not been registed with UoW.");

	}
}
