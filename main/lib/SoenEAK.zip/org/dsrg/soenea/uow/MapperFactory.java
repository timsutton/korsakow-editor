package org.dsrg.soenea.uow;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;

import org.dsrg.soenea.domain.DomainObject;
import org.dsrg.soenea.domain.mapper.GenericOutputMapper;
import org.dsrg.soenea.environment.ParameterizedFactory;
import org.dsrg.soenea.environment.mapper.ResourceMapper;
import org.dsrg.soenea.environment.matcher.ResourceMatcher;
import org.dsrg.soenea.service.KeyValuePair;


public class MapperFactory extends ParameterizedFactory<DomainObject<?>, GenericOutputMapper<?, ?>, KeyValuePair<?, ?>> {

	public MapperFactory() {
		super(
		 new ResourceMapper <DomainObject<?>, GenericOutputMapper<?, ?>, KeyValuePair<?, ?>>() {
			public GenericOutputMapper<?, ?> Create(DomainObject<?> key,
					KeyValuePair<?, ?> resource) throws ClassNotFoundException,
					IllegalArgumentException, SecurityException,
					InstantiationException, IllegalAccessException,
					InvocationTargetException, NoSuchMethodException {
				return ((Class<GenericOutputMapper<?, ?>>)resource.getValue()).newInstance();
			}		
		},
		new ResourceMatcher<DomainObject<?>, KeyValuePair<?, ?>>() {

			public boolean isMatch(DomainObject<?> key, KeyValuePair<?, ?> resource) {
				return resource.equals(key.getClass());
			}
			
		},
		new LinkedList<KeyValuePair<?, ?>>());
	}
	
	public <IDField, DO extends DomainObject<IDField>> void addMapping(Class<? extends DO> key, Class<? extends GenericOutputMapper<IDField, DO>> value) {
		((LinkedList<KeyValuePair<?, ?>>)getResourceSource()).add(new KeyValuePair(key, value));
	}
	
	public <IDField, DO extends DomainObject<IDField>> boolean contains(Class<DO> key) {
		for(KeyValuePair<?, ?> kvp :((LinkedList<KeyValuePair<?, ?>>)getResourceSource())) {
			if(kvp.getKey().equals(key)) return true;
		}
		return false;
	}
	
}
