package org.dsrg.soenea.environment;

public class KeyNotFoundException extends Exception {

	/**
	 * If, while looking for a key/resource match, one can't find one, 
	 * this is the Exception to throw.
	 * 
	 */
	private static final long serialVersionUID = -1044636605287127002L;

	public KeyNotFoundException(Object key) {
		super(key.getClass().getName() + " (" + key.toString() + ") Not Found.");
	}

}
