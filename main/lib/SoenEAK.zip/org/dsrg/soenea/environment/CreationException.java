package org.dsrg.soenea.environment;

/**
 * When a mapper tries to create something for the factory and something goes wrong, 
 * this is what gets thrown. 
 * 
 * I don't think it applies to the mapper, but I'm not yet sure if I've come fully 
 * down off the fence on that one. It may not seem like it makes sense to consider 
 * it for the matcher, but I listen to my insincts a lot, and while I can't see 
 * anything, I'm trying to keep my eyes open.
 * 
 * @author Stuart Thiel
 *
 */
public class CreationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3242689860362986983L;

	public CreationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CreationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CreationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CreationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
