package org.dsrg.soenea.environment;

import org.dsrg.soenea.environment.matcher.*;
import org.dsrg.soenea.environment.mapper.*;

/**
 * The concept here is that we use factories everywhere. What is a factory? It's something
 * that, given criteria, returns an instance of the appropriate type. It seemed to me that
 * paramaterizing a factory would let it be reused to a higher degree, so I've attempted 
 * to give a nice generic approach to doing so.
 * 
 * I've sort of failed, having to kludge things a little bit. However, it still works on
 * simple cases, so I will continue to poke at it till I get something that feels perfect.
 * 
 * That said, it breaks the concept of a factory into looping over available resources
 * until it matches a given key. At this point, given the key and the found resource, it
 * will map the resource and/or key onto/into some appropriate instance and return this.
 * 
 * That's pretty vague, but that's about all it really does.
 * 
 * @author Stuart Thiel
 *
 * @param <KeyType>
 * @param <ResultingType>
 * @param <ResourceType>
 */
public class ParameterizedFactory <KeyType, ResultingType, ResourceType> {
	Iterable<ResourceType> resourceSource;
	ResourceMatcher<KeyType, ResourceType> resourceMatcher;
	ResourceMapper<KeyType, ResultingType, ResourceType> resourceMapper;
	
	/**
	 * 
	 * @param mapper
	 * Something to map the Key/Resource to an appropriate ResultungType instance.
	 * @param matcher
	 * Something to verify that we've found a valid Key/Resource combo.
	 * @param source
	 * Something that will provide us with access to the Resources that we're allowed
	 * to look at.
	 */
	public ParameterizedFactory(ResourceMapper<KeyType, ResultingType, ResourceType> mapper, 
								ResourceMatcher<KeyType, ResourceType> matcher, 
								Iterable<ResourceType> source) {
		resourceMapper = mapper;
		resourceMatcher = matcher;
		resourceSource = source;
	}

	public Iterable<ResourceType> getResourceSource() {
		return resourceSource;
	}

	/**
	 * Given a key, the factory will attempt to return an appropriate instance.
	 * 
	 * @param key
	 * @return
	 * @throws KeyNotFoundException
	 * If we cycle through all the resources and find no match, we'll throw this exception.
	 * @throws CreationException
	 * If while trying to map (or maybe even match), something goes horribly wrong, we'll 
	 * wrap the exception (or just create one) and throw this.
	 */
	public ResultingType getInstance(KeyType key) throws KeyNotFoundException, CreationException {
		for(ResourceType r: resourceSource) {
			if(resourceMatcher.isMatch(key, r)) {
				try {
					return resourceMapper.Create(key, r);
				} catch (Exception e) {
					throw new CreationException(e);
				}
			}
		}
		throw new KeyNotFoundException(key);
	}
	
}
