package org.dsrg.soenea.environment.mapper;

import java.lang.reflect.InvocationTargetException;

/**
 * Are you sick of all the reflection required to get the instances you want from thin
 * air? So am I! This creates an instance of something using the default constructor. 
 * What it is specified via generics.
 * 
 * One annoying thing is that I've not got around inheriting/implementing the generics
 * stuff. This is probably because it's compile-time, not runtime, which is boatloads of
 * suck, but what can you do? This may have more consequences than I've realized.
 * 
 * @author Stuart Thiel
 *
 * @param <KeyType>
 * @param <ResultingType>
 * @param <ResourceType>
 */
public class LookupClassMapper<KeyType, ResultingType, ResourceType> implements ResourceMapper<KeyType, ResultingType, ResourceType> {

	/**
	 * This method really doesn't intend to pass parameters, but we have a key. Therefore 
	 * we just throw away the key and call this method to use the default constructor for
	 * the specified ResultingType.
	 * 
	 * All the exceptions are related to reflection... boring.
	 * 
	 * @param key
	 * @param resource
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IllegalArgumentException
	 * @throws SecurityException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	public ResultingType Create(KeyType key, ResourceType resource) throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		return (ResultingType) Class.forName(key.toString()).newInstance();
	}
}
