package org.dsrg.soenea.environment.mapper;

import java.lang.reflect.InvocationTargetException;

/**
 * This should take a key and a resource and map them to something of the appropriate
 * ResultingType. This is the core of the Factory part of ParameterizedFactory.
 * 
 * @author Stuart Thiel
 *
 * @param <KeyType>
 * @param <ResultingType>
 * @param <ResourceType>
 */
public interface ResourceMapper <KeyType, ResultingType, ResourceType> {
	public ResultingType Create(KeyType key, ResourceType resource)  throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException;
}
