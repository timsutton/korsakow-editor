package org.dsrg.soenea.environment.mapper;

import java.lang.reflect.InvocationTargetException;

/**
 * Unlike LookupClassMapper, we're actually creating instances using the passed key as
 * an argument to pass with the Construtor. Of course, if we got a valued match, one 
 * assumes this will work. If not, ClassCastException fun will ensue.
 * 
 * @author Stuart Thiel
 *
 * @param <KeyType>
 * @param <ResultingType>
 * @param <ResourceType>
 * @see org.dsrg.soenea.factory.LookupClassMapper
 */
public class KeyedClassMapper <KeyType, ResultingType, ResourceType> implements ResourceMapper<KeyType, ResultingType, ResourceType> {

	/**
	 * Using the constructor of the ResultingType that takes one parameter of KeyType, 
	 * we reflexively instantiate.
	 * 
	 * @param key
	 * @param resource
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IllegalArgumentException
	 * @throws SecurityException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	public ResultingType Create(KeyType key, ResourceType resource) throws ClassNotFoundException, IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Class<ResultingType> c = (Class<ResultingType>)Class.forName(resource.toString());
		return c.getConstructor(new Class[]{key.getClass()}).newInstance(new Object[]{key});
	}
}
