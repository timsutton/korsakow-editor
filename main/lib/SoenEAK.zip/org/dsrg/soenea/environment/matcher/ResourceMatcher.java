package org.dsrg.soenea.environment.matcher;

/**
 * All ResourceMatchers should be prepared to determine whether there
 * is a match between the provided key and the provided resource. In 
 * simple terms, this might be equality of strings, but in a more 
 * complex example, it might be a check for matching a String representation
 * of a class to a valid String representation of a parent Class. 
 * 
 * @author Stuart Thiel
 *
 * @param <KeyType>
 * @param <ResourceType>
 */
public interface ResourceMatcher <KeyType, ResourceType> {

	/**
	 * 
	 * @param key
	 * @param resource
	 * @return
	 * true if a match is found, false otherwise. What constitutes a match
	 * will always be implementation specific.
	 */
	boolean isMatch(KeyType key, ResourceType resource);

}
