package org.dsrg.soenea.environment.matcher;

/*
 * This assumes a resource will be a StringArray of size two, with the first element being the key 
 * to match against, and the second being the resources value. Matchers only want to match the 
 * search key with the other key, so we only look at the first piece.
 */

public class StringPairMatcher implements ResourceMatcher {

	public boolean isMatch(Object key, Object resource) {
		return key.equals(((String[])resource)[0]);
	}
}
