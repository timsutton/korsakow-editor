package org.dsrg.soenea.environment.matcher;


/**
 * Do you ever want to match something without really having anything to match?
 * In this case, we have the ever easy AlwaysMatcher, which will always return 
 * true, no matter what you give it.
 * 
 * @author Stuart Thiel
 *
 */
public class AlwaysMatcher<KeyType, ResourceType> implements ResourceMatcher<KeyType, ResourceType> {

	public boolean isMatch(KeyType key, ResourceType resource) {
		return true;
	}

}
