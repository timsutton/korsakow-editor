package org.dsrg.soenea.environment.matcher;

/*
 * The simplest form of matching.
 */
public class SimpleMatcher<KeyType, ResourceType> implements ResourceMatcher<KeyType, ResourceType> {
	public boolean isMatch(KeyType key, ResourceType resource) {
		return resource.equals(key);
	}
}
