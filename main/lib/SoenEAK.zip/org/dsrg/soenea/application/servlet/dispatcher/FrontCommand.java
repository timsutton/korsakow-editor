package org.dsrg.soenea.application.servlet.dispatcher;

public abstract class FrontCommand extends Dispatcher {

	public int getInt(String pName)
	  throws NumberFormatException {
		return myHelper.getInt(pName);
	}
	
	public long getLong(String pName)
	  throws NumberFormatException {
		return myHelper.getLong(pName);
	}
	
	public String getString(String pName){
		return myHelper.getString(pName);
	}
	
	public String[] getValues(String pName){
		return myHelper.getValues(pName);
	}
	
	public void setRequestAttribute(String key, Object value) {
		myHelper.setRequestAttribute(key, value);
	}
	
	public Object getRequestAttribute(String key) {
		return myHelper.getRequestAttribute(key);
	}
	
	public boolean getBoolean(String pName) {
		return myHelper.getBoolean(pName);
	}

}
