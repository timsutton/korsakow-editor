package org.dsrg.soenea.application.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dsrg.soenea.service.PropertyRegistry;
import org.dsrg.soenea.service.Registry;
import org.dsrg.soenea.service.PropertyRegistry.PropertyInUseException;
import org.dsrg.soenea.service.threadLocal.DbRegistry;
import org.dsrg.soenea.service.threadLocal.SessionThreadLocalRegistry;
import org.dsrg.soenea.service.threadLocal.ThreadLocalTracker;
/**
 * Superclass to soenEA.* servlets.
 * @author  chalin and thiel
 * @version 2.8
 */
public abstract class Servlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7343541027400545634L;
	
	protected /*@non_null@*/ String errorJSP = null;
	private static String propertyFile = "Myresources.properties";
	private static String propertyName = "errorJSP";
	private static String propertyDefault = "/error.jsp";
	
	static {
		try {
			PropertyRegistry.registerProperty(propertyName, new PropertyRegistry.Property(propertyName, 
					"This property should contain the relative path (relative to the servlet base) of the error JSP to " +
					"be used. It will default to \"" + propertyDefault + "\", in the servlet base if the property is not set.", propertyFile));
		} catch (PropertyInUseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
    /** 
     * Initializes the servlet.
     * 
     * If an "ErrorJSP" is specified in the init-params, it will
     * be used whenever there is an error. Otherwise, errors will
     * be directed to the default Error.jsp.
     * 
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        
        try {
			errorJSP = Registry.getProperty(propertyName);
			if(errorJSP == null || errorJSP.equals("")) throw new Exception ("empty property.");
		} catch (Exception e) {
			log(e.getMessage());
			errorJSP = propertyDefault;
		}
    }

	/** 
	 * Processes requests for both HTTP <code>GET</code> and 
	 * <code>POST</code> methods.
	 * 
	 * All this does is attempt to create a FrontCommand and execute it. 
	 * The only time this method does anything itself besides initiating 
	 * the above actions is when there is a problem, at which point it will
	 * forward to the Error JSP page.
	 * 
	 * @param request servlet request
	 * @param response servlet response
	 */
	protected void execute(
		HttpServletRequest request,
		HttpServletResponse response)
		throws ServletException, java.io.IOException //
	{
		preProcessRequest(request, response);
		processRequest(request, response);
		postProcessRequest(request, response);
	}
	
	protected abstract void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, java.io.IOException;

	protected void postProcessRequest(HttpServletRequest request, HttpServletResponse response) {
		try {
			DbRegistry.closeDbConnectionIfNeeded();
		} catch (Exception e) {
			//It's ok to throw this away... that's the point. If something is really
			//going wrong, we'll catch it elsewhere. I guess that's the theory.
		}
		ThreadLocalTracker.purgeThreadLocal();
	}

	protected void preProcessRequest(HttpServletRequest request, HttpServletResponse response) {
		SessionThreadLocalRegistry.setSession(request.getSession(true));
	}
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    //@ also requires request != null && response != null;
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
    	execute(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    //@ also requires request != null && response != null;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
    	doGet(request, response);
    }
}
