package org.dsrg.soenea.application.servlet;

public class MissingParameterException extends Exception {

	private static final long serialVersionUID = -5608169542974767574L;

	/* Parameter name stored, for convenience, as a separate field,
	 * independent of the message.
	 */
	private String parameterName = "";

	public MissingParameterException(String message) {
		super(message);
	}
	
	public MissingParameterException(Throwable t) {
		super(t);
	}
	
	public MissingParameterException(String message, Throwable t) {
		super(message, t);
	}
	
	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

}
