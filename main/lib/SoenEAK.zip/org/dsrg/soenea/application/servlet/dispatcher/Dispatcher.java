package org.dsrg.soenea.application.servlet.dispatcher;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dsrg.soenea.domain.helper.Helper;

/**
 * A dispatcher is responsible for dispatching the request sent by the Front Command
 * to one or more session commands. <br/>
 * Classes which inherit from Dispacher must implement the execute method.
 */
public abstract class Dispatcher {
	protected HttpServletRequest myRequest = null;			//The request object that is passed by the Front Command
	protected HttpServletResponse myResponse = null;		//The response object that is passed by the Front Command
	protected Helper myHelper = null;		//Used to package information
	
	public void init(HttpServletRequest req, HttpServletResponse res) {
		myRequest = req;
		myResponse = res;
		myHelper = new HttpServletHelper(req);
	}
	
	public abstract void execute() throws ServletException, IOException;
	
	/**
	 * Forwards the request to the target, relative to the current file, as long as the target remains 
	 * within context root of the servlet.
	 * 
	 * Paths beginning with '/' will be relative to the context root.
	 * 
	 * @param target
	 * @throws java.io.IOException
	 * @throws ServletException
	 */
	protected void forward(String target)
	  throws java.io.IOException, ServletException {
		myRequest.getRequestDispatcher(target).forward(myRequest, myResponse);
	}

	/**
	 * Includes the results of a dispatch to the target, relative to the current file, as long as the 
	 * target remains within context root of the servlet.
	 * 
	 * Paths beginning with '/' will be relative to the context root.
	 * 
	 * @param target
	 * @throws java.io.IOException
	 * @throws ServletException
	 */
	protected void include(String target)
	  throws java.io.IOException, ServletException {
		myRequest.getRequestDispatcher(target).include(myRequest, myResponse);
	}
	
	protected void redirectToDispatcher(Dispatcher my_dispatcher) throws ServletException, IOException {
		my_dispatcher.init(myRequest, myResponse);
		my_dispatcher.execute();
	}
	
}
