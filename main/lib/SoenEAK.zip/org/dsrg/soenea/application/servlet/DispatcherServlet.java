package org.dsrg.soenea.application.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dsrg.soenea.application.servlet.dispatcher.Dispatcher;
import org.dsrg.soenea.application.servlet.service.DispatcherFactory;

/**
 * The parent of FrontControllers or PageControllers that would use Dispatchers 
 * @author  sthiel
 */
public class DispatcherServlet extends Servlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7343541027400545675L;

    /** 
     * Initializes the servlet.
     * 
     * If an "ErrorJSP" is specified in the init-params, it will
     * be used whenever there is an error. Otherwise, errors will
     * be directed to the default Error.jsp.
     * 
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

	/** 
	 * Processes requests for both HTTP <code>GET</code> and 
	 * <code>POST</code> methods.
	 * 
	 * All this does is attempt to create a FrontCommand and execute it. 
	 * The only time this method does anything itself besides initiating 
	 * the above actions is when there is a problem, at which point it will
	 * forward to the Error JSP page.
	 * 
	 * @param request servlet request
	 * @param response servlet response
	 */
	protected void processRequest(
		HttpServletRequest request,
		HttpServletResponse response)
		throws ServletException, java.io.IOException //
	{
		try {
			Dispatcher dispatcher = DispatcherFactory.getInstance(getDispatcherName(request));
			dispatcher.init(request, response);
			dispatcher.execute();
		} catch (Exception e) {
			request.setAttribute("errorMessage", e.getMessage());
			request.setAttribute("exception", e);
			request.getRequestDispatcher(errorJSP).forward(request, response);
		}
	}
	
	/**
	 * This tries to get the command (dispatcher) name from the request, first
	 * looking for a parameter, and then an attribute with the name 'dispatcher'.
	 * 
	 * @param request
	 * @return non-null and non-empty command name.
	 * @throws ServletException
	 * Whenever there is no command in the request, an Exception to that effect
	 * will be thrown.
	 */
	protected String getDispatcherName(HttpServletRequest request) throws ServletException {
		String parameterName = "dispatcher";
		String dispatcherName = request.getParameter(parameterName);
		if (dispatcherName != null && !dispatcherName.equals(""))
			return dispatcherName;
		dispatcherName = (String) request.getAttribute(parameterName);
		if (dispatcherName != null && !dispatcherName.equals(""))
			return dispatcherName;
		MissingParameterException e = new MissingParameterException(parameterName);
		throw new ServletException(e);
	}
	
	public String getParameter(HttpServletRequest request, String parameterName) throws ServletException {
		String param = request.getParameter(parameterName);
		if (param == null) {
			MissingParameterException e = new MissingParameterException(parameterName);
			throw new ServletException(e);
		}
		return param;
	}

	public Object getAttribute(HttpServletRequest request, String attributeName) throws ServletException {
		Object param = request.getAttribute(attributeName);
		if (param == null) {
			MissingAttributeException e = new MissingAttributeException(attributeName);
			throw new ServletException(e);
		}
		return param;
	}

}
