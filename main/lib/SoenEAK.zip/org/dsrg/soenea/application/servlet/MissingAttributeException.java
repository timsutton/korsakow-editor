package org.dsrg.soenea.application.servlet;

public class MissingAttributeException extends Exception {

	private static final long serialVersionUID = -5608169542974767574L;

	/* Attribute name stored, for convenience, as a separate field,
	 * independent of the message.
	 */
	private String attributeName = "";

	public MissingAttributeException(String message) {
		super(message);
	}
	
	public MissingAttributeException(Throwable t) {
		super(t);
	}
	
	public MissingAttributeException(String message, Throwable t) {
		super(message, t);
	}
	
	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributerName(String parameterName) {
		this.attributeName = parameterName;
	}

}
