package org.dsrg.soenea.application.servlet.dispatcher;

import javax.servlet.http.HttpServletRequest;

import org.dsrg.soenea.domain.helper.Helper;

public class HttpServletHelper implements Helper {

	protected HttpServletRequest myRequest = null;
	
	public HttpServletHelper(HttpServletRequest myRequest) {
		super();
		this.myRequest = myRequest;
	}

	public int getInt(String pName)
	  throws NumberFormatException {
		return Integer.parseInt(getString(pName));
	}
	
	public long getLong(String pName)
	  throws NumberFormatException {
		return Long.parseLong(getString(pName));
	}
	
	public float getFloat(String pName)
	  throws NumberFormatException {
		return Float.parseFloat(getString(pName));
	}

	public double getDouble(String pName)
	  throws NumberFormatException {
		return Double.parseDouble(getString(pName));
	}

	public String getString(String pName){
		return myRequest.getParameter(pName);
	}
	
	public String[] getValues(String pName){
		return myRequest.getParameterValues(pName);
	}
	
	public void setRequestAttribute(String key, Object value) {
		myRequest.setAttribute(key, value);
	}
	
	public Object getRequestAttribute(String key) {
		return myRequest.getAttribute(key);
	}
	
	public boolean getBoolean(String key) {
		try {
			return Boolean.parseBoolean(getString(key));
		} catch (NullPointerException e) {
			return false;
		}
	}

	public Object getSessionAttribute(String key) {
		return myRequest.getSession(true).getAttribute(key);
	}

	public void setSessionAttribute(String key, Object value) {
		myRequest.getSession(true).setAttribute(key, value);
	}

	public String getSessionId() {
		return myRequest.getSession(true).getId();
	}
	
	public Object getApplicationAttribute(String key) {
		return myRequest.getSession(true).getServletContext().getAttribute(key);
	}

	public void setApplicationAttribute(String key, Object value) {
		myRequest.getSession(true).getServletContext().setAttribute(key, value);
	}
	public Object getAttribute(String key)
	{
		Object value;
		if ((value=getRequestAttribute(key)) != null)
			return value;
		if ((value=getSessionAttribute(key)) != null)
			return value;
		if ((value=getApplicationAttribute(key)) != null)
			return value;
		return null;
	}
}
