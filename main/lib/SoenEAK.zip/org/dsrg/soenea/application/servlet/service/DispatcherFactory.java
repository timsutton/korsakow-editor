package org.dsrg.soenea.application.servlet.service;

import java.util.LinkedList;

import org.dsrg.soenea.application.servlet.dispatcher.Dispatcher;
import org.dsrg.soenea.environment.CreationException;
import org.dsrg.soenea.environment.KeyNotFoundException;
import org.dsrg.soenea.environment.ParameterizedFactory;
import org.dsrg.soenea.environment.mapper.LookupClassMapper;
import org.dsrg.soenea.environment.matcher.AlwaysMatcher;

/**
 * This factory is responsible for creating instances of classes inherited from
 * Dispatcher. As with other factories, this class uses the Singleton pattern.
 * 
 * @author Stuart Thiel
 *
 */
public class DispatcherFactory {
	
	private static String dummyValue = "";					//An empty value, used to initialize a list
	private static ParameterizedFactory<String, Dispatcher, String> internalFactory;	//The instance of the singleton 
	
	/**
	 * As with other singletons, the getInstance() method returns the instance of the factory or makes a new one.<br/>
	 * It does so by using the key, which comes in the from a request of a specific command, using the canonical class name.<br/>
	 * Therefore, the requested command determines the key, which in turn determines the type of dispatcher 
	 * that the factory will return.  
	 *    
	 * @param key Is the command sent in the request object
	 * @return An instance of a Dispatcher object
	 * @throws KeyNotFoundException
	 * @throws CreationException	
	 */
	public static Dispatcher getInstance(String key) throws KeyNotFoundException, CreationException {
		return (Dispatcher)getInternalFactory().getInstance(key);
	}

	/**
	 * This method is responsible for either returning the dispatcher instance or creating one
	 * if one has not been made yet. <br/>
	 * 
	 * The first generic parameter is the key, which is the command in the request object.<br/>
	 * The second generic parameter is the resulting type, which is the type of dispatcher being 
	 * created based on the desired command.<br/>
	 * The third generic parameter is the resource type, which is not being used by this class. 
	 */
	private synchronized static ParameterizedFactory<String, Dispatcher, String> getInternalFactory() {
		if(internalFactory==null) {
			LinkedList<String> l = new LinkedList<String>();
			l.add(dummyValue); 	//Here we pass an empty string to the list. We then pass the empty list
								//This is done because there is no resource type but we still need to pass
								//A "full" list to ParameterizedFactory. 
			LookupClassMapper<String, Dispatcher, String> lcm = new LookupClassMapper<String, Dispatcher, String>();
			AlwaysMatcher<String, String> am = new AlwaysMatcher<String, String>();
			internalFactory = new ParameterizedFactory<String, Dispatcher, String>(lcm, am, l);
		}
		return internalFactory;
	}
	
	
}
