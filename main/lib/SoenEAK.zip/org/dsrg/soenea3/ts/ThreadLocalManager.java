package org.dsrg.soenea3.ts;

import java.util.List;
import java.util.Vector;

/**
 * Using this class you can <code>register</code> your {@link ThreadLocal}s
 * so that they can all be reset (set to null) by a single call to
 * <code>setAllToNullForCurrentThread()</code>. This is needed by
 * Servlet-based applications since some servlet containers like Tomcat reuse
 * threads, and hence ThreadLocals need to be cleaned up (reset) before a new
 * thread can make use of them.
 */
public class ThreadLocalManager {

	// For Servlet based EAs, I (PC) don't think that the list should itself be
	// a ThreadLocal. If we did so, we would have unnecessarily duplicated lists
	// ...

	// private static ThreadLocal<List<ThreadLocal>> threadLocals = new
	// ThreadLocal<List<ThreadLocal>>() { protected synchronized
	// List<ThreadLocal>
	// initialValue() { return new ArrayList<ThreadLocal>(); } };

	// Using Vector instead of ArrayList because the former is thread-safe and
	// the latter is not.
	private static List<ThreadLocal<?>> threadLocals = new Vector<ThreadLocal<?>>();

	private static List<ThreadLocal<?>> getList() {
		return threadLocals;
		// return threadLocals.get();
	}

	public static void register(ThreadLocal<?> t) {
		assert t != null;
		getList().add(t);
	}

	/**
	 * Calls <code>ThreadLocal.remove()</code> on all registered
	 * <code>ThreadLocal</code>s. Hence, the next time the
	 * <code>ThreadLocal</code>s are accessed, their
	 * <code>ThreadLocal.initialValue()</code> methods will be called. Of
	 * course, this has as an effect to remove the values for the current thread
	 * only.
	 */
	public static void resetAllThreadLocalForCurrentThread() {
		for (ThreadLocal<?> tl : getList()) {
			tl.remove(); // TODO: double check that access to tl is
			// thread-safe.
		}
	}
}
