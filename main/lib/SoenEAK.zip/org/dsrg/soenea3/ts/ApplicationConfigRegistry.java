package org.dsrg.soenea3.ts;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * A registry used to hold global application configuration parameters held in
 * properties file. The base name of the properties file (<code>fileName</code>) can be changed.
 * 
 * Designer notes: this class implements Martin Fowler's Registry Pattern (where the underlying
 * implementation is a Singleton).  The singleton can be reset for testing purposes.
 * 
 * @author Patrice Chalin
 */
public class ApplicationConfigRegistry {

	/*@ spec_public */ private static /*!@ nullable */ 
	ApplicationConfigRegistry soleInstance = null;

	public static final /*@ non_null */ String defaultFileName = "MyResources";
	/*@ spec_public */ private static /*@ non_null */ 
	String fileName = defaultFileName;

	private /*@ non_null */ ResourceBundle myResourceBundle;

	/*@ public normal_behavior
	  @   requires soleInstance != null;
	  @   assignable \nothing;
	  @   ensures \result == soleInstance;
	  @ also public behavior
	  @   requires soleInstance == null;
	  @   assignable soleInstance;
	  @   ensures \result == soleInstance;
	  @   ensures \result != null;
	  @   signals_only MissingResourceException;
	  @*/
	public synchronized static /*@ non_null */ ApplicationConfigRegistry getUniqueInstance()
			throws MissingResourceException {
		if (soleInstance == null) {
			/*@ non_null */ ApplicationConfigRegistry 
			reg = new ApplicationConfigRegistry();
			// If we reach this point it is because reg was successfully loaded.
			// In the case an exception is generated, then the caller needs to handle it.
			soleInstance = reg;
		}
		return soleInstance;
	}
	
	/*@ protected behavior
	  @   assignable \not_specified;
	  @   signals_only MissingResourceException, NoSuchPropertyException;
	  @*/
	public static /*@ non_null */ String getProperty(String key)
			throws MissingResourceException, NoSuchPropertyException {
		return getUniqueInstance()._getProperty(key);
	}

	/*@ private behavior
	  @   assignable myResourceBundle;
	  @   signals_only MissingResourceException;
	  @*/
	private ApplicationConfigRegistry() throws MissingResourceException {
		myResourceBundle = ResourceBundle.getBundle(fileName);
	}

	/*@ private behavior
	  @   assignable \not_specified;
	  @   // signals_only NoSuchPropertyException;
	  @*/
	private /*@ non_null */ String _getProperty(String key)
			throws NoSuchPropertyException 
	{
		String value;
		try {
			value = myResourceBundle.getString(key);
		} catch (MissingResourceException e) {
			throw new NoSuchPropertyException(e.getMessage(), key);
		}
		return value;
	}

	public static /*@ non_null */ String getFileName() {
		return fileName;
	}

	public static void setFileName(/*@ non_null */ String fileName) {
		ApplicationConfigRegistry.fileName = fileName;
	}

	/*@ normal_behavior
      @   assignable soleInstance, fileName;
      @   ensures soleInstance == null
      @        && fileName == defaultFileName;
      @*/
	/*package*/ static void testModeReset() {
		soleInstance = null;
		fileName = defaultFileName;
	}

}
