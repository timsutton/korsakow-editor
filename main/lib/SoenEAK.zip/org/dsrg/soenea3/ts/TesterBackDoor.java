package org.dsrg.soenea3.ts;

/**
 * This public class is a back door that testers can use to access
 * some "hidden" (i.e. package scoped) features which are normally
 * meant to be inaccessible to clients outside this package.
 * 
 * @author Patrice Chalin
 *
 */
public class TesterBackDoor {

	/*@ public normal_behavior
	  @   assignable ApplicationConfigRegistry.soleInstance,
	  @              ApplicationConfigRegistry.fileName;
	  @   ensures ApplicationConfigRegistry.soleInstance == null
      @   && ApplicationConfigRegistry.fileName == ApplicationConfigRegistry.defaultFileName;
	  @*/
	public static void resetApplicationConfigRegistry() {
		ApplicationConfigRegistry.testModeReset();
	}
	
	public void DbConnRegistry_setInstance(SDbConnRegistry reg) {
		DbConnRegistry.setInstance(reg);
	}
}
