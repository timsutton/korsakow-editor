package org.dsrg.soenea3.ts;

import java.sql.Connection;

/**
 * Thread-safe DbRegistry.
 * @see Fowler's <a href="http://www.martinfowler.com/eaaCatalog/registry.html">Registry</a>.
 */
public class DbConnRegistry {

	/* Designer notes:
	 * - Each thread has its own <code>_instance</code>.
	 * - Even though this class presents its services via static methods,
	 *   these static methods are implemented via delegation to 
	 *   <code>instance</code>.  This will make it easier to substitute, e.g.,
	 *   a testing stub.
	 */
	
	private static ManagedThreadLocal<SDbConnRegistry> _instance = new ManagedThreadLocal<SDbConnRegistry>() {
        protected synchronized SDbConnRegistry initialValue() {
            return new SDbConnRegistry();
        }
	};
	private static SDbConnRegistry instance = (SDbConnRegistry) _instance.get();
	
	public static void resetInstance() {
		instance = (SDbConnRegistry) _instance.get();
	}
	
	/*package*/ static void setInstance(SDbConnRegistry reg) {
		instance = reg;
	}
	
	//@ public model Connection dbConnection;
	//@ private represents dbConnection = instance.dbConnection;

	/*@ public behavior
	  @   assignable \not_specified;
	  @   ensures \result == dbConnection != null && !dbConnection.isClosed();
	  @   signals (Exception) true;
	  @*/
	public static boolean isConnected() throws DbConnRegistryException {
		return instance.isConnected();
	}

	/**
	 * If isConnected(), then returns dbConnection, the current connection.
	 * Otherwise, attempts to create a new connection and return it.
	 */
	public static /*@non_null*/ Connection getDbConnection() throws DbConnRegistryException {
		return instance.getDbConnection();
	}

	/**
	 * If isConnected(), then attempts to close the connection (which
	 * may result in an exception being thrown).
	 */
	//@ ensures !isConnected();
	public static void closeDbConnection() throws DbConnRegistryException {
		instance.closeDbConnection();
	}
}
