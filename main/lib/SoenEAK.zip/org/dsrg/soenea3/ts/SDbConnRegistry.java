package org.dsrg.soenea3.ts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.MissingResourceException;

/**
 * This class implements a DbRegistry (for single-threaded applications).
 * 
 * @see Fowler's <a
 *      href="http://www.martinfowler.com/eaaCatalog/registry.html">Registry</a>.
 */
public class SDbConnRegistry {

	protected/* @nullable */Connection dbConnection;

	/*
	 * @ public behavior 
	 * @ assignable \not_specified; 
	 * @ ensures \result == dbConnection != null && !dbConnection.isClosed(); 
	 * @ signals (Exception) true; 
	 * @
	 */
	public boolean isConnected() throws DbConnRegistryException {
		try {
			return dbConnection != null && !dbConnection.isClosed();
		} catch (SQLException e) {
			throw new DbConnRegistryException(e);
		}
	}

	/**
	 * If isConnected(), then returns dbConnection, the current connection.
	 * Otherwise, attempts to create a new connection and return it.
	 */
	public/* @non_null */Connection getDbConnection() throws DbConnRegistryException {
		if (!isConnected()) {
			initDbConnection();
		}
		return dbConnection;
	}

	/*
	 * @ public behavior 
	 * @ assignable \not_specified; 
	 * @ ensures !isConnected(); 
	 * @ signals (Exception) true; // when attempt to close failed. 
	 * @
	 */
	public void closeDbConnection() throws DbConnRegistryException {
		if (isConnected()) {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				String msg = "Attempt to close database connection failed.";
				throw new DbConnRegistryException(msg, e);
			}
		}
		dbConnection = null;
	}

	/*
	 * @ private behavior 
	 * @ assignable \not_specified; 
	 * @ ensures dbConnection != null; 
	 * @ signals (Exception) true; 
	 * @
	 */
	private void initDbConnection() throws DbConnRegistryException //
	{
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch (ClassNotFoundException e) {
			String msg = "Cannot request a database connection because the MySQL driver cannot be found.";
			throw new DbConnRegistryException(msg, e);
		}

		String usr = "UNKNOWN (properties file not access)";
		String url = "UNKNOWN (properties file not access)";
		try {
			String host = ApplicationConfigRegistry
					.getProperty("mySqlHostName");
			String dbn = ApplicationConfigRegistry.getProperty("mySqlDatabase");
			String pwd = ApplicationConfigRegistry.getProperty("mySqlPassword");
			usr = ApplicationConfigRegistry.getProperty("mySqlUserName");

			url = "jdbc:mysql://" + host + "/" + dbn;
			if ("anonymous".equals(usr)) {
				dbConnection = DriverManager.getConnection(url);
			} else {
				dbConnection = DriverManager.getConnection(url, usr, pwd);
			}
		} catch (MissingResourceException e) {
			String msg = "Database properites file access failed.";
			throw new DbConnRegistryException(msg, e);
		} catch (NoSuchPropertyException e) {
			String msg = "Mandatory property missing from properties file.";
			throw new DbConnRegistryException(msg, e);
		} catch (SQLException e) {
			String msg = "Attempt to obtain a database connection failed for "
					+ "user " + usr + ", url " + url;
			throw new DbConnRegistryException(msg, e);
		}
	}
}
