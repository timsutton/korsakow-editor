package org.dsrg.soenea3.ts;

/**
 * Instances of this class are like normal instances of {@link ThreadLocal}
 * except that the instances auto-register themselves with the
 * {@link ThreadLocalManager}. Having a separate class makes it easy to detect
 * if we have forgot to register any ThreadLocals by simply looking for
 * occurrences of <code>new ThreadLocal()</code>.
 */
public class ManagedThreadLocal<T> extends ThreadLocal<T> {

	public ManagedThreadLocal() {
		super();
		ThreadLocalManager.register(this);
	}

}
