package org.dsrg.soenea3.ts;

public class NoSuchPropertyException extends Exception {

	private static final long serialVersionUID = 3639920700231964963L;

	private String propertyName;

	public NoSuchPropertyException(String s, String propertyName) {
        super(s);
        this.propertyName = propertyName;
    }

	public String getPropertyName() {
		return propertyName;
	}
}
