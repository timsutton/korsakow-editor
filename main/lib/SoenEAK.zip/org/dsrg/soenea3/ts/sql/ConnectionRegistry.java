package org.dsrg.soenea3.ts.sql;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.MissingResourceException;

import org.dsrg.soenea3.ts.ApplicationConfigRegistry;
import org.dsrg.soenea3.ts.ManagedThreadLocal;
import org.dsrg.soenea3.ts.NoSuchPropertyException;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

/** 
 * This registry returns a connection to <em>the</em> database for this
 * application.  Note that each thread calling <code>getConnection()</code>
 * gets its own connection.
 * 
 * To close the connection, invoke <code>close()</code> on it.
 * 
 * @author dsrg.org
 */
/* <h3>Design notes</h3>
 * 
 * <ul>
 * <li> This should in fact be a DataSource Registry, but for our needs, it is
 * actually the connection that we want and there is only one way to request it
 * (contrast this situation to Finders which may have several methods offering a
 * lookup service for a particular kind of Domain Model).
 * 
 * <li> This implementation is bound to MySQL (as it is the only DataSource that
 * we are currently using).
 * </ul>
 */
public class ConnectionRegistry {

	public static Connection getConnection() throws SQLException {
		return ConnectionRegistry.getInstance()._getConnection();
	}

	//-----------------------------------------------------------------------
	// Singleton pattern part:
	
	private static /*@ non_null */ ManagedThreadLocal<ConnectionRegistry> theOne = new ManagedThreadLocal<ConnectionRegistry>();
	
	private static synchronized ConnectionRegistry getInstance() throws SQLException {
		if(theOne.get() == null) {
			theOne.set(new ConnectionRegistry());
		}
		return (ConnectionRegistry) theOne.get();
	}

	//-----------------------------------------------------------------------
	// Basic (non-singleton) class declarations proper:
	
	private static final String ERR_MSG1 = "could not identify data source due to failure to access properties file: ";

	private Connection connection;

	private ConnectionRegistry() throws SQLException {
		init();
	}
	
	/*@ private behavior
	  @   assignable \not_specified;
	  @   ensures dbConnection != null;
	  @   signals (Exception) true;
	  @*/
	private/* @helper */ void init() throws SQLException {
		MysqlDataSource ds = new MysqlDataSource();

		String dbIdent = "properties identifying database are unknown";
		try {
			String host = ApplicationConfigRegistry.getProperty("mySqlHostName");
			String dbn = ApplicationConfigRegistry.getProperty("mySqlDatabase");
			String pwd = ApplicationConfigRegistry.getProperty("mySqlPassword");
			String usr = ApplicationConfigRegistry.getProperty("mySqlUserName");
			dbIdent = "host '" + host + "', database '" + dbn + "', user '" + usr + "'";
			ds.setServerName(host);
			ds.setDatabaseName(dbn);
			connection = "anonymous".equals(usr)
					? ds.getConnection()
					: ds.getConnection(usr, pwd);
		} catch (MissingResourceException e) {
			String msg = ERR_MSG1;
			throw new SQLException(msg + e);
		} catch (NoSuchPropertyException e) {
			String msg = ERR_MSG1;
			throw new SQLException(msg + e);
		} catch (SQLException e) {
			throw new SQLException("failed to getConnection for " + dbIdent + ".");
		}
	}

	private Connection _getConnection() {
		return connection;
	}
}
