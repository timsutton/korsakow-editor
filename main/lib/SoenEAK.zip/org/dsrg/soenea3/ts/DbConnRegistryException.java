package org.dsrg.soenea3.ts;

public class DbConnRegistryException extends Exception {

	public DbConnRegistryException(String msg, Exception e) {
		super(msg,e);
	}

	public DbConnRegistryException(Exception e) {
		super(e);
	}

	private static final long serialVersionUID = 6844724665246506013L;
}
